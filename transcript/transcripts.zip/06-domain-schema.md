# Session 06 — Domain schema, constraints and seed (#2)

- **Date:** 2026-11-19
- **Agent/model:** opencode-go/deepseek-v4.1-flash
- **Goal:** Grill issue #2 into a schema design, then implement the six core tables, constraints, migration and idempotent seed.
- **Outcome:** Six tables with UUIDv7 keys and integer-cent money, one Alembic revision, an idempotent Acme Bank/ShopFast seed, and 21 passing tests. PR #29.
- **Issues/commits:** #2; `5b48eaf` (schema), `babb727` (review pass), `0bd6909` (test trim); https://github.com/aritako/dcc-sms-gateway/pull/29
- **Complete export:** `06-domain-schema.json` (inside transcripts.zip)

## Conversation

### 1. User — start grilling

> Let's $grilling Issue #2. We need to make the necessary schemas for the following, according to the tech spec: tenants, messages, message events, ledger entries and prices.

### Assistant — facts first

Read issue #2 and the downstream tickets that pin column needs (#5, #6, #9, #10, #11, #13, #16), plus the existing Alembic setup, pytest harness and READMEs. No tech-spec document existed in the repo, so the first question asked whether the issue set was authoritative.

### 2. User — round 1 answers

| Question | Choice |
| --- | --- |
| Spec source | Issue set is the spec |
| Deliverable scope | Database layer only (models, migration, seed, tests) |
| Primary keys | UUIDv7 everywhere |
| Enum storage | `VARCHAR` + named `CHECK` constraints |
| Forward columns | Strict #2 minimum plus `ledger_entries.balance_after_cents` |
| Ledger kinds | `CHARGE`, `REFUND`, `CREDIT` |
| API-key hashing | SHA-256 hex |
| Seed policy | Fixed demo keys, tenants/keys `DO NOTHING`, prices upsert |

### 3. User — attached the brief

> [File: DCC_SMS_Gateway_Take_Home_Assignment-v2.docx.pdf] More context if you need it.

The PDF was extracted with `uvx pypdf` (no `pdftotext` in the environment). It confirmed the issue set: the same seven statuses, signed ledger rule, tenant isolation and minimum API surface. No conflicting requirements.

### 4. User — round 2 answers

| Question | Choice |
| --- | --- |
| Opening balance | Two columns, no opening ledger row |
| Price snapshot | Store `segments`, `price_per_segment_cents`, `total_price_cents` on the message |
| Currency | Tenant-only, immutable USD |
| Extra DB checks | Enforce the arithmetic, sign and presence invariants |
| Tenant natural key | Unique `name` |

### 5. User — round 3 answers

| Question | Choice |
| --- | --- |
| DESIGN.md | Defer docs to #22 |
| Ledger tenant consistency | Composite `(message_id, tenant_id)` FK to messages |

### 6. User — challenge on `_cents`

> is spelling out cents necessary in the table columns? i guess i assume since we are dealing with per SMS messaging, the price hovers around that. maybe some example rows for all of the tables would help me out in judging.

### Assistant — kept `_cents`, showed example rows

Explained that the suffix records the unit, not the magnitude, and that issue #2 names `balance_cents` and `amount_cents` literally. Provided example rows for all six tables, including:

- Acme Bank with 100,000 cents and two messages (GSM7 OTP and Bangla UCS2);
- ShopFast with 1,000,000 cents, a failed message, a refund and a top-up `CREDIT`;
- The ledger chain and the invariant `balance = opening + SUM(amount_cents)`.

### 7. User — kept the suffix

> Keep _cents everywhere (Recommended)

### 8. User — implement

> Implement now please, if you need to write stuff down for the specs and tickets please do it locally via scratch dir (or any gitignored sesh)

### Assistant — implementation

- Added `app/db/base.py` (naming convention) and `app/db/models.py`:
  - `tenants` (`name` unique, opening/current balance, currency);
  - `api_keys` (SHA-256 `key_hash`, unique);
  - `prices` (`prefix` unique, per-segment cents);
  - `messages` (queue row with `status`, `available_at`, `carrier`, nullable `carrier_id`, price snapshot);
  - `message_events` (`unique(message_id, status)`);
  - `ledger_entries` (signed `amount_cents`, `balance_after_cents`, `unique(message_id, kind)`, composite tenant/message FK).
- Added the checks: non-negative balances, kind/sign, message presence, price arithmetic, status/encoding/kind, E.164/sender/text/prefix/currency/key-hash formats.
- Added the query indexes, including the partial unique `(carrier, carrier_id)`.
- Added `app/security.py` with SHA-256 key hashing.
- Replaced the seed placeholder with an idempotent, single-transaction seed for Acme Bank (100,000), ShopFast (1,000,000), demo keys and `+880`/`+971` prices.
- Added migration `0d3c682e1245_domain_schema.py` on top of the empty init revision; set `target_metadata = Base.metadata` in `migrations/env.py`.
- Documented demo keys and pricing in `README.md`.

Found and fixed a naming bug during verification: check constraints were being double-prefixed (`ck_api_keys_ck_api_keys_...`) because the naming convention was applied to already-qualified names. Changed the `ck` convention to pass through full names.

### 9. User — review round

> for indices, i prefer this naming format: "idx_<first_column>", "idx_<first_col>_<second_col>" and so on.

> can we guarantee that this will be correct? given stuff like floating point arithmetic

> Trim. Please just state what it does.

> Omit.

> for the purposes of this assignment, we can omit this entire test file.

> can also omit this test file.

### Assistant — review changes

- Answered the floating-point question: `segments` is `INTEGER`, the two price columns are `BIGINT`; PostgreSQL and Python multiply integers exactly, so the check is exact.
- Renamed indexes to `idx_<columns>`. Because Postgres index names are schema-wide, the ledger `(tenant_id, created_at)` index is `idx_ledger_entries_tenant_id_created_at`; the messages one is `idx_tenant_id_created_at`.
- Trimmed the seed docstring to one line.
- Reverted the `config.attributes` URL override in `migrations/env.py`.
- Deleted `tests/test_migrations.py` and `tests/test_seed.py`.
- Committed as `babb727`.

### 10. User — accepted the trade-off

> its fine, i think the issues are a bit too overboard with the acceptance criteria for something that is only an assignment.

### 11. User — one more test trim

> omit.

Attached to `test_constraint_names_are_stable`.

### Assistant — removed the test

Deleted `test_constraint_names_are_stable`; `test_required_indexes_exist` remains. Lint and mypy pass, 20 tests collect. Committed as `0bd6909`.

### 12. User — PR and transcript

> Open a pr with $pr please. Then write a transcript for this session.

### Assistant — PR and export

- Postgres was available again, so reset the local schema and `sms_test`, re-migrated, re-seeded twice, and reran the suite: **20 passed**.
- Pushed `t3/initial-db-schemas`, opened **PR #29**, and linked it to the thread.
- Exported this session to `06-domain-schema.json`.

### 13. User — diagram rendering

> Unable to render diagram on the description

### Assistant

Replaced the Mermaid ER block with a plain-text relationship diagram so it renders in both GitHub and T3.

### 14. User — drop the carrier_id index

> Drop idx_carrier_id. DLRs are identified by (carrier, carrier_id), and the partial unique index already covers that lookup. An extra index on a busy table slows every insert and update for no benefit.
>
> Correct me if Im wrong.

### Assistant

Agreed for the documented DLR lookup: the partial unique `(carrier, carrier_id)` index serves `WHERE carrier = ? AND carrier_id = ?`, while the standalone index only helps a bare `carrier_id` query the design does not have. Dropped it, updated the migration and index test, reset the local databases and reran: 20 passed, `alembic check` clean. Committed as `40c5176`.

### 15. User — index naming consistency

> The index names don’t match your naming convention. base.py defines ix_%(table_name)s_..., but the migration uses names like idx_status_available_at, and most of them don’t include the table name. Postgres index names must be unique across the whole schema, and Alembic autogenerate will report a mismatch between models and migration. Pick one style and use it everywhere.

### Assistant

Standardized on `idx_<table>_<columns>`: changed the `ix` naming convention to that pattern and renamed every explicit index to match, including the partial unique. The descending expression index stays explicit because the convention cannot resolve a text expression's column name, but it follows the same pattern. Reset the local databases, reran `alembic check` (clean) and the suite (20 passed). Committed as `135a381`.

### 16. User — missing client_ref

> client_ref is missing. The brief lists it as an optional field on POST /v1/messages, so it needs a column, presumably returned with the message.

### Assistant

Added nullable `messages.client_ref` to the model and migration. The send and detail APIs (#6/#9) will return and filter it; no index yet because no query needs one beyond the tenant/date path. Reset the local databases, reran `alembic check` (clean) and the suite (20 passed). Committed as `5af2e78`.

### 17. User — retry the Mermaid diagram

> Also please try again visualizing the mermaid diagram, its better to visualize that way.

### Assistant

The earlier ER block failed because Mermaid requires a label after each relationship. Added labels (`: owns`, `: sends`, `: records`, `: billed_by`), verified the diagram renders with a Mermaid renderer, and restored it in PR #29.

### 18. User — final council

> Looks good, run one last $council to deliberate whether these are the MINIMUM REQUIRED CHANGES just for the assignment. The goal is to rapidly iterate a prototype in the first place.

### Assistant — two council rounds

**Round 1** (DeepSeek 7/10, GLM 9/10, Muse 7/10). All three agreed the only required fix was the missing seed-idempotency + ledger-invariant proof from issue #2's AC. They split on over-engineering (format CHECKs, `updated_at`, `client_ref`); `client_ref` was explicitly requested, and the CHECKs were a prior design choice, so those were recorded rather than churned.

Added one combined test, `test_seed_is_idempotent_and_the_ledger_explains_the_balance`, in `gateway/tests/test_schema.py` (commit `a667196`): seed twice, exact tenants/keys/prices, a changed balance survives, and a charge/refund chain satisfies `balance = opening + SUM(ledger)`.

**Round 2** (DeepSeek 9/10, GLM 10/10, Muse 10/10). DeepSeek's residual: the `-3/+3` pair nets to zero, so the identity assertion is weaker than it reads; recorded as a follow-up, not blocking. No third round. The council table was added to PR #29.

## Settled design

```text
tenants 1─* api_keys
tenants 1─* messages 1─* message_events
tenants 1─* ledger_entries *─1 messages (composite tenant FK)
```

- UUIDv7 primary keys, generated in Python.
- Money is `BIGINT` cents; the ledger is signed (`CHARGE < 0`, `REFUND/CREDIT > 0`).
- Opening balance is a column; the ledger starts empty.
- Message price is snapshotted at accept time.
- Currency is tenant-level and immutable; both seeded tenants use USD.
- Deferred to owning tickets: `batch_id`, `next_attempt_at`, lease columns, `billing_state`, event source/carrier timestamps, API-key revocation, `webhook_url`, idempotency keys, `dlr_inbox`, `submit_attempts`.
- `DESIGN.md` deferred to #22 by request.

## Verification

```text
$ make lint typecheck test
All checks passed!
Success: no issues found in 12 source files
21 passed in 0.59s

$ uv run alembic check
No new upgrade operations detected.

$ make seed && make seed
tenants=2 api_keys=2 prices=2 balance_sum=1100000
```

## Tool activity

- `gh issue view` for #2 and downstream tickets; read `gateway/` models, migrations, settings and test harness.
- Extracted the attached PDF with `uvx --from pypdf` after `pdftotext` was unavailable.
- Three `question` rounds to settle the design tree.
- Wrote `app/db/base.py`, `app/db/models.py`, `app/security.py`, `app/seed.py`, the Alembic revision, `migrations/env.py`, `tests/test_schema.py`, and the README seed section.
- Ran `alembic upgrade/downgrade/check`, `make seed` repeatedly, `make lint typecheck test`.
- Review pass: renamed indexes, trimmed comments, deleted `tests/test_migrations.py`, `tests/test_seed.py` and `test_constraint_names_are_stable`.
- `git commit` `5b48eaf`, `babb727`, `0bd6909`, `40c5176`, `135a381`, `5af2e78`, `a667196`; `git push`; `gh pr create` → PR #29; `gh pr edit 29`; linked the PR.
- Verified the labeled Mermaid ER diagram with a renderer after the first block failed to parse.
- Ran the two-round council: three `delegate_task` calls per round with DeepSeek V4.1 Flash, GLM-5.3-Flash and Muse Spark 1.3 Contributor; added the combined seed/ledger test and the PR council table.
- `opencode session export ses_e107bfcfbffekwJktNEHNBTcMq` → `06-domain-schema.json`.
