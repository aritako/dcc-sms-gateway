# Session 10 — Issue #7 live smoke test and tenant status report

- **Date:** 2026-11-20
- **Agent/model:** opencode-go/deepseek-v4.1-flash
- **Goal:** Verify the just-merged issue #7 (`Idempotency-Key` for message sends) against the running Docker Compose stack, provide a repeatable script/curls, and report tenant status.
- **Outcome:** Found the dev database one migration behind and applied it. Live checks pass: same key/body replays the same message with one charge; same key/different body returns `409 IDEMPOTENCY_KEY_REUSED`; 10 concurrent duplicates produce one message and one charge. Added `scripts/smoke.py`, which runs those checks and prints a per-tenant table (`tenant`, `messages`, `opening`, `ledger`, `balance`) plus three `RESULT` lines. `gateway/tests/test_messages.py` is green (19 passed) and ruff passes on the script.
- **Issues/commits:** #7; `main` is at `2716b7a` (`feat(gateway): replay idempotent message sends (#33)`). No new commits; `scripts/` is currently untracked.
- **Complete export:** `10-issue-7-smoke-test.json` (inside transcripts.zip)

## Transcript

### User

“Just merged our changes for issue 7. Can you help me test out our system right now? Give me a script or a curl or something and the end should print thre results”

### Assistant

Inspected the repo and issue #7 context: the last commit is `2716b7a` and issue #7 covers `Idempotency-Key` on `POST /v1/messages`, tenant-scoped key replay, `409` on a changed body, concurrent duplicate serialization, and 2xx-only storage. Read the message controller, handler, models, idempotency service and tests.

The Docker Compose stack was already running (`api`, `carrier`, `postgres`, `redis`, `worker`), and `/healthz` returned `{"db":"ok","redis":"ok"}`. However, the first live send returned `500`:

```text
sqlalchemy.exc.ProgrammingError: relation "idempotency_keys" does not exist
```

The dev database was still on Alembic revision `0d3c682e1245`; the new `e40134aacff4` migration had not been applied. Ran:

```bash
make migrate   # 0d3c682e1245 -> e40134aacff4
```

Then verified manually with curl: first send `202`, replay with the same key/body `202` with the same id, changed body `409 {"error":"IDEMPOTENCY_KEY_REUSED"}`, and balance dropped by exactly 3 cents. Created an initial bash script with three checks:

1. Same key/body twice → one message id and one charge.
2. Same key/different body → `409`, no second charge.
3. Ten concurrent duplicates → all `202`, one message id and one charge.

Ran it twice; each run produced exactly three messages and three charges, and the concurrent group produced one message/charge. The gateway test suite for the send path also passed: `19 passed` for `tests/test_messages.py`.

### User

“can it be a python script please? it should neatly report in the terminal about the status of the tenant        messages     opening    ledger     balance”

### Assistant

Replaced the bash helper with a Python script using `httpx` for the live API and `psycopg` for the tenant table. Deleted the bash file and created `scripts/smoke_issue_7.py`.

The script:

- Runs the same three checks with unique per-run idempotency keys.
- Uses `GET /v1/balance` deltas to prove exactly one charge.
- Queries PostgreSQL for each tenant’s total messages, opening balance, signed ledger sum and current balance.
- Prints a table with the requested columns, followed by the three `RESULT` lines. It exits `0` only when all checks pass.

Example output:

```text
Tenant status (amounts in cents)
Tenant     Messages    Opening  Ledger    Balance
-------------------------------------------------
Acme Bank        10    100,000     -30     99,970
ShopFast          0  1,000,000       0  1,000,000

RESULT 1 PASS  replay: both 202, same id ..., one charge (3 cents)
RESULT 2 PASS  conflict: different body returned 409 IDEMPOTENCY_KEY_REUSED, no second charge
RESULT 3 PASS  concurrent: 10 duplicates all 202, one id ..., one charge (3 cents)
```

The table makes the ledger invariant visible (`100,000 + (-30) = 99,970`) and shows the second seeded tenant untouched.

### User

“Rename it to just smoke.py”

### Assistant

Renamed `scripts/smoke_issue_7.py` to [scripts/smoke.py](../scripts/smoke.py), updated the run command in the docstring and import-error message, and reran it successfully. The script is executable and is run through the gateway environment:

```bash
uv run --project gateway python scripts/smoke.py
```

Ruff check and format check both pass.

### User

“Can you give me sample curls”

### Assistant

Provided copy-paste curls for:

- First send and same-key/same-body replay (`202`, same id).
- Same key with a different body (`409 IDEMPOTENCY_KEY_REUSED`).
- Ten concurrent duplicates with `curl` background jobs and `jq` to show one unique id.
- `GET /v1/balance`.
- Reusing the same idempotency key under the ShopFast tenant to show per-tenant key scope.
- `POST /v1/messages/quote`.
- `GET /healthz`.

Also included the expected status-code summary.

### User

“write on transcript please”

### Assistant

Exported this session from the main checkout on `main` to `transcript/10-issue-7-smoke-test.json` using:

```bash
opencode session export "$OPENCODE_SESSION_ID" > transcript/10-issue-7-smoke-test.json
```

and wrote this Markdown summary. Raw transcript files are ignored by Git; only the cumulative `transcripts.zip` is committed at submission. The raw export contains the documented local demo keys and compose dev secrets, so a targeted redaction pass is still needed before building that zip.

## Tool activity

- Read `git log`, `git status`, `README.md`, `docker-compose.yaml`, `.env.example`, the message controller/handler/models, `idempotency.py`, `test_messages.py`, the balance controller, seed data and the idempotency migration.
- Ran `docker compose ps`, checked `localhost:8000/healthz` and `localhost:8001/healthz`.
- Reproduced the `500` on send; read `docker compose logs api` and found `relation "idempotency_keys" does not exist`.
- Queried `alembic_version` and the schema with `psql`; applied `make migrate` from `0d3c682e1245` to `e40134aacff4`.
- Ran manual curls for send, replay, conflict and balance; verified same id, `409`, and a single 3-cent charge.
- Created `scripts/smoke-issue-7.sh`, ran it twice, checked message/charge/event counts and the ledger sum with `psql`.
- Ran `cd gateway && uv run pytest tests/test_messages.py -q` → `19 passed`.
- Replaced the bash helper with `scripts/smoke_issue_7.py` using `httpx` + `psycopg`; verified the tenant table and three checks.
- Renamed the script to `scripts/smoke.py`; updated the internal usage text.
- Ran `uv run --project gateway python scripts/smoke.py`; latest table showed Acme with 22 messages, opening 100,000, ledger -66, balance 99,934, and ShopFast with 0 messages and 1,000,000 cents.
- Ran `ruff check` and `ruff format --check` on `scripts/smoke.py`; both pass.
- Exported the complete session to `transcript/10-issue-7-smoke-test.json` and wrote this summary.
