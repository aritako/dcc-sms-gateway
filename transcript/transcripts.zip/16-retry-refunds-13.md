# Session 16 — Retry, timeout ambiguity and refunds (#13)

- **Date:** 2026-11-21
- **Agent/model:** opencode-go/deepseek-v4.1-flash (variant high)
- **Goal:** Implement GitHub issue #13 (MVP “Keep” scope plus absorbed #14), review it with a three-seat council, address reviewer feedback, rebase, merge PR #40, and extend the load script with retry/refund metrics.
- **Outcome:** Issue #13 implemented and merged in PR #40 (`d983ac1`). Final branch head `9a0333d`; 163 gateway tests pass; ruff/mypy clean; council found no blockers after follow-up. `scripts/run_1k.py` now reports attempts, retries, timeouts, refunds and billing review.
- **Issues/commits:** #13; PR #40; merge commit `d983ac1`; branch commits `cf7905d`, `c6d5593`, `761372c`, `2496781`, `cf71a6d`, `d3eed03`, `1c7f4c3`, `7c15087`, `06e0133`, `9a0333d`.
- **Complete export:** `16-retry-refunds-13.json` (inside `transcripts.zip`)

## Transcript

### User

Implement GitHub issue #13 in the worktree: retry classification, backoff, timeout ambiguity and refunds. MVP “Keep” scope only. Read `AGENTS.md`, `gh issue view 13` including absorbed #14, and the worker/billing/DLR/API/migration/test files. Build:

- classification: 200 accepted; 400 `INVALID_DESTINATION` permanent; 429/503/5xx/network transient; timeout ambiguous;
- `submit_attempts` with outcome/status/error/timestamps, one row per real submit outside the carrier transaction;
- nullable `messages.next_attempt_at`, `COALESCE` claim predicate, waiting retries stay `QUEUED`;
- jittered exponential backoff (1, 2, 4, 8, 16 s, cap 30), configurable, limiter re-acquired per retry;
- `MAX_ATTEMPTS` exhaustion on definitive non-acceptance → conditional `FAILED` + exactly one refund;
- `BillingService.refund()` exactly-once via the ledger unique key and `ON CONFLICT DO NOTHING ... RETURNING`;
- ambiguous-only timeout exhaustion → `FAILED` + `billing_state=REVIEW`, no refund;
- timeout retries the same `message_id`;
- migration for `submit_attempts`, `next_attempt_at`, `billing_state`;
- expose `billing_state` on message detail;
- new `gateway/tests/test_retry.py` covering seven listed scenarios;
- keep `docker compose up` as the entry point; do not touch compose/Makefile/scripts/main checkout;
- open a PR against `main` ending with `Closes #13`.

### Assistant

Inspected the repository and ticket, then implemented the slice:

- Added `SubmitAttempt`, `SubmitOutcome`, `BillingState`, `messages.next_attempt_at`, `messages.billing_state`, and the migration `f7b2c9d14e60_add_retry_policy.py`. `submit_attempts` has a per-message unique attempt number and outcome/HTTP-status checks.
- Reworked `Dispatcher.claim()` to use `COALESCE(next_attempt_at, available_at)` in both the predicate and ordering, and to clear `next_attempt_at` while taking a fresh lease.
- Reworked `dispatch()` to classify timeouts separately from other `httpx` transport errors, record every attempt, and settle through retry, `SUBMITTED`, or failure.
- Added jittered exponential backoff (`0.5–1.0` multiplier), configurable via `max_submit_attempts`, `retry_backoff_base_seconds`, `retry_backoff_cap_seconds`.
- Added a conditional, idempotent `_fail()` and `BillingService.refund()`; the refund locks the tenant row and credits only when the `(message_id, kind)` ledger insert wins.
- Ambiguous history at exhaustion sets `billing_state=REVIEW` and suppresses the refund. Accepted evidence blocks failure/refund.
- Exposed `billing_state` on `GET /v1/messages/{id}`.
- Added `gateway/tests/test_retry.py` for 503→200, 400, exhausted 503, concurrent finalisation, timeout→200, timeout-only exhaustion, and `next_attempt_at` claiming.
- Result: 149 tests passed, ruff/mypy clean. Opened PR #40 (`87d5af3`).

### User

“Let’s review the changes, please” (`$council`).

### Assistant

Ran the three-seat council (DeepSeek, GLM, Muse) over PR #40. Three rounds:
- Round 1: scores 7/8/8. Fixed mixed-exhaustion semantics (any ambiguous attempt → `REVIEW`, not just all-ambiguous), attempt-number races (row lock + unique constraint), `SUBMITTED` finalisation, and malformed-200 liveness.
- Round 2: scores 8/8.5/8. Added an acceptance-evidence guard, recovery for a lost `record_submitted`, and terminal-timeline suppression. Fixed attempt/leak evidence, malformed 200 handling, and test flakiness.
- Round 3: scores 9/9/10. No blockers. Updated the PR description with the score table.
- Final original-review head: `78a27f7`; 155 tests.

### User

“Why doesn’t it have any CSS if I try to open it via [the T3 asset URL]?”

### Assistant

Diagnosed the T3 asset route: its token is scoped to the opened file’s `baseRelativePath` (`lessons`), so `../assets/course.css` returned 404. Fixed the teaching workspace by adding same-directory symlinks (`lessons/course.css`, `lessons/quiz.js`, `reference/course.css`) and same-directory cross-document links, so the lesson and references load under the T3 server. Confirmed CSS/JS returned 200.

### User

“While I review, can you rebase from main? I did a test suite cleanup.”

### Assistant

Fetched `main`, rebased cleanly onto `0fa13ff` (the test-cleanup merge), ran the new suite (163 passed), force-pushed with `--force-with-lease`, and updated the PR test count. CI passed.

### User

Review comments on `dispatch.py`:
1. “Why do we set `next_attempt_at` to `None`? When do we set it to a meaningful value?”
2. “Too verbose. Cut it down please” on the `retry_or_fail` docstring.

### Assistant

Explained that claiming clears the retry clock so `COALESCE` falls back to the fresh lease; `retry_or_fail` sets it to `now() + backoff(...)` only when scheduling, and success/failure clear it. Also explained that the claim orders by earliest due time across fresh sends and retries, not retry-first. Shortened the docstring in `2496781`.

### User

Review comment: “How is this possible? Shouldn’t a 200 always return a carrier id?” on the malformed-200 branch.

### Assistant

Explained the branch guarded contract violations (proxy HTML 200, truncated/schema-drifted body, missing carrier id). The user then said to descope it; removed the branch, helper, and test in `cf71a6d`, trusting `response.json()["carrier_id"]` directly. Updated the PR description and test count (162).

### User

Review comment: “Why do we have assertions in code? Would prefer normal try/catch logic.”

### Assistant

Replaced the attempt-numbering assert with an `or 1` fallback (`d3eed03`). Then, at the user’s request, also replaced the pre-existing idempotency replay assert with an explicit incomplete-row check raising `RuntimeError` (`1c7f4c3`). No asserts remain in `app/`.

### User

“Might as well clean up that assert too. After, let’s run a `$council` to review the changes.”

### Assistant

Convened a follow-up council on head `1c7f4c3`:
- Round 1: scores 8/8/9. Findings: late 200 on a refunded `FAILED` message left `billing_state=NORMAL`; backoff exponent could overflow in the accepted-recovery loop; retry-window tests had a timing-sensitive lower bound; retry settings were missing from `.env.example`; the 400-after-timeout path differed from exhaustion semantics.
- Fixes in `7c15087`: late 200 sets `REVIEW`; documented and tested the 400-after-timeout policy (carrier dedupe makes a later 400 definitive); clamped the exponent; captured pre-dispatch timestamps; documented `MAX_SUBMIT_ATTEMPTS`/`RETRY_BACKOFF_*`.
- Round 2: scores 9/9/10, no blockers. Updated the PR description with the follow-up table.

### User

Review comment: “We already have a `StubLimiter` in the helper.”

### Assistant

Removed the duplicate `StubLimiter`, `make_dispatcher`, and `event_statuses` from `test_retry.py`; imported the shared helpers. Extended the shared `make_dispatcher` with optional settings overrides. Commit `06e0133`; 163 tests.

### User

“Anything to update in `run_1k`? Maybe listing the retries, timeouts, refunds?”

### Assistant

Extended `scripts/run_1k.py` to query the run’s message ids and report:
- gateway attempts and outcome breakdown (`ACCEPTED`/`TRANSIENT`/`AMBIGUOUS`/`PERMANENT`);
- retried messages and max attempt number;
- ambiguous/timeout attempts;
- refund count and cents;
- `billing_state=REVIEW` count.
Commit `9a0333d`; `py_compile` clean; gateway tests unchanged. Noted the script change in the PR summary.

### User

“Alright, let’s merge this thing.”

### Assistant

Auto-merge was unavailable (repository permission/configuration), so watched the pending checks. When `Lint, typecheck and test` passed on `9a0333d`, merged PR #40 with a merge commit. Final merge commit: `d983ac1`.

### User

“Then write into the transcript please.”

### Assistant

Exported the complete session to `transcript/16-retry-refunds-13.json`, redacted the one `OPENCODE_PASSWORD` value found in tool output, and wrote this summary.

## Decisions

- PostgreSQL remains the queue; Redis is only the global limiter (and SSE elsewhere).
- Every real submit is recorded after the HTTP call, never inside a database transaction spanning the carrier.
- The claim predicate is one timeline: fresh sends use `available_at`, waiting retries use `next_attempt_at`; clearing the retry clock on claim makes the lease authoritative during a submit.
- A 400 is permanent and refundable even after a timeout, because the mock carrier dedupes by `message_id`; an accepted earlier attempt would have returned 200.
- Any ambiguous attempt at exhaustion means the carrier may have delivered, so the charge is held (`REVIEW`) rather than refunded.
- Refunds are exactly-once through the ledger unique `(message_id, kind)` and `ON CONFLICT DO NOTHING ... RETURNING`; only the winning insert credits the tenant.
- A committed `ACCEPTED` attempt always blocks failure/refund. A late 200 after `FAILED` keeps the terminal outcome but raises `REVIEW`.
- Malformed-200 defensive handling was deliberately descoped at review time; the code trusts the carrier’s 200 contract.
- Deferred: generated `due_at` index, exact backoff-number assertions, `billing_state` UI, 429-limiter unit test, and `DESIGN.md` (#22).

## Council

Original review (head `78a27f7`):

| Delegate | Round 1 | Round 2 | Round 3 |
| --- | --- | --- | --- |
| DeepSeek V4.1 Flash | 7/10 | 8/10 | 9/10 |
| GLM-5.3-Flash | 8/10 | 8.5/10 | 9/10 |
| Muse Spark 1.3 | 8/10 | 8/10 | 10/10 |

Follow-up after reviewer feedback (head `7c15087`):

| Delegate | Round 1 | Round 2 |
| --- | --- | --- |
| DeepSeek V4.1 Flash | 8/10 | 9/10 |
| GLM-5.3-Flash | 8/10 | 9/10 |
| Muse Spark 1.3 | 9/10 | 10/10 |

No blockers remained after the follow-up round.

## Tool activity

- `gh issue view 13` — read the ticket and absorbed #14.
- Read `gateway/app/worker/{dispatch,worker,limiter}.py`, `db/models.py`, `core/{billing,dlr}.py`, `settings.py`, message/DLR API files, migrations, and tests.
- Wrote models, migration, dispatch, billing, settings, read model and `test_retry.py`.
- `uv run pytest`, `uv run ruff check .`, `uv run mypy` — repeated; final 163 passed, clean.
- `alembic downgrade`/`upgrade`/`check` on `sms_test` — verified the migration and model parity.
- Opened PR #40; updated its description several times with test counts, policy notes, and council tables.
- Council delegates (`delegate_task`) — three seats, two review cycles; collected scores and findings.
- `git rebase origin/main`, `git push --force-with-lease` — clean rebase after the test cleanup.
- `git commit`/`git push` — docstring trim, descope, assert cleanups, late-200 review flag, backoff clamp, test-helper reuse, `run_1k` metrics.
- `python3 -m py_compile scripts/run_1k.py`.
- `pull_request_merge` — merged PR #40 as `d983ac1`.
- `opencode session export` — complete JSON export, then targeted password redaction.

## Final state

- PR #40 merged: `https://github.com/aritako/dcc-sms-gateway/pull/40`
- Merge commit: `d983ac1`
- Branch head at merge: `9a0333d`
- Tests: `163 passed`; ruff/mypy clean
- Transcript: `16-retry-refunds-13.json` + `16-retry-refunds-13.md`
