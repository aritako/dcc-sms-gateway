# Session 13 — Worker dispatch (#10), 1,000-message run and PR #36

- **Date:** 2026-11-21
- **Agent/model:** opencode-go/deepseek-v4.1-flash (OpenCode / T3 Code)
- **Goal:** Land ticket #10's MVP path — claim with a lease, `QUEUED`, carrier submit, the global 45/s slot limiter, three replicas — and record evidence that workers process and submit.
- **Outcome:** Merged PR #36 (`2f3aee2`). 133 tests pass, `ruff` and `mypy` clean, a recorded 1,000-message run with 40 retries, zero 429s and zero stuck messages. Remaining: the 3-dispatcher ≤50/s test, the SIGKILL reclaim test, an unreachable-Redis test, and the DESIGN.md write-up.
- **Issues/commits:** issue #10; PR #36; merge `2f3aee2`; branch `feat/workers-10` commits `e68db23` → `08b36d3`
- **Complete export:** `13-worker-dispatch-10.json` (inside transcripts.zip)

## Transcript

### User — where to start

> Can you give me tips on how to start Issue 10? Based on my understanding of the spec, I'm thinking of writing out a CarrierRateLimit, i.e. throttling the amount of submits our workers do to the carrier. I guess this is important especially for stuff like batch messaging with 10,000 messages needed to send. Then after, we should probably increase worker replicas as well, so more can concurrently process the queue and send to the Carrier. Whats next after that

Read ticket #10 and the repository. Established that the ticket's `MVP path` blockquote, not the full acceptance criteria, is the definition of done.

Corrections to the plan:

- The claim loop comes before the limiter, not after — but the limiter's call site should exist from the first commit so there is structurally "no bypass path".
- Replicas *before* the Redis limiter multiply the rate by three; they only become safe once the limiter is global.
- Once the limiter exists, replicas buy latency hiding, not throughput. Three serial workers against 20–300 ms carrier latency reach ~18/s and never touch the 45/s cap, so bounded concurrency inside each worker is what makes the ceiling the limiter.
- At 40/s sustained, 10,000 messages is ~4 minutes; batch send caps at 1,000, so it is ten calls.

Also flagged: `available_at` can double as the lease (no `lease_expires_at` column), `messages.submitted_at` does not exist yet, and `submit_attempts` belongs to #13.

### User — one-by-one build order

> one by one, what code should we write up in sequence?

Nine steps: migration for `submitted_at`; settings; limiter; carrier client; queue module; dispatcher; entrypoint; three-replica proof; SIGKILL test. Each with the test that ends the step.

### User — why the Lua script

> Why the lua script? is that more optimal than a pure python implementation

Answered no: at 40 increments/second the performance difference is noise. Corrected an earlier overstatement — a lost `PEXPIRE` cannot seal a future slot because keys are slot-namespaced; it is only a memory leak (≈1.7M keys/day if it never expires). `pipeline(transaction=True)` gives the same atomicity and one round trip, and is what the final code uses.

### User — review of limiter.py

> Look at what I have for limiter.py. Is this valid? Walk me through it line by line

Line-by-line review. Math verified: `45 × 50 // 1000 = 2` permits per slot, 21 slots per rolling second, 42 maximum. Findings:

- `settings.ge=1` allows a rate below 20/s, where `per_slot` becomes 0 and `acquire()` never returns; the constructor's `ValueError` then fires at worker startup instead of proofing the setting. Recommended `ge=20`.
- Fail-closed is a caller obligation because `acquire()` raises. Acceptable, but it must be caught inside the per-message task or a `TaskGroup` cancels the whole batch.
- `pexpire(key, 2 * SLOT_MS)` is thin: the key is computed from a `TIME` read before the pipeline, so a stalled EXEC can land after expiry and recreate the counter. Recommended `10 * SLOT_MS` (no cost, keys never recur).

### User — "1 permit/slot?"

> why would are you suggesting 1 permit/slot? that would mean we only get 20 requests per second which is way below our 50req/s carrier limit

Clarified that `ge=20` is a validation floor, not the configured rate. At 45 the limiter grants 2 permits/slot = 40/s sustained. Also documented that the scheme quantises to 20/40/60 per second, so 50 configured still yields 40 — 40 is the highest safe value under a 50/s ceiling, which is the ticket's stated trade-off.

### User — dispatcher design and when to set QUEUED

> now lets talk about the dispatcher. From my understanding, the workers are independent services that will just read from the Messages table, ordered by available_at (ascending, so first in, first out), and it uses with FOR UPDATE query so that we can optimistically lock a row ... i was thinking though when to set the status to QUEUED. probably during claim of dispatch?

Three corrections: `FOR UPDATE` is pessimistic locking, not optimistic; FIFO is approximate because a batch shares one `now()`, so `id` is needed as a tiebreaker; a retry deliberately leaves FIFO order.

`QUEUED` belongs in the claim transaction, before any HTTP: the row lock is gone after commit, so from then on `available_at` (the lease) is what keeps other workers out. Setting `QUEUED` later gains no safety and makes the database lie about what the worker owns. Event order `ACCEPTED → QUEUED → SUBMITTED` also depends on it.

Also flagged that `Redis.from_url` has no `socket_timeout`, so a blackholed Redis hangs `TIME` forever instead of failing closed.

### User — claimable statuses

> so should my CLAIMABLE constant also include ACCEPTED and QUEUED?

Yes. `ACCEPTED` means never claimed; `QUEUED` means claimed before and either still leased (future `available_at`) or released (past `available_at`). Status and time do different jobs.

### User — is a sessionmaker session a transaction

> is the sessionmaker() session a transaction?

Yes, implicitly: autobegin on the first statement, ended by `commit()`/`rollback()`, and a close rolls back anything uncommitted. That is why "no transaction across HTTP" means "commit, then call the carrier".

### User — add the claim code

> Can you please add the code needed in my claim function

Rewrote `claim()` from `UPDATE ... WHERE id IN (SELECT ... FOR UPDATE)` into `SELECT ... FOR UPDATE SKIP LOCKED` followed by `UPDATE ... RETURNING`, so lock ownership is explicit and the `WHERE id IN (ids)` cannot miss. Added the `(available_at, id)` ordering.

Three defects found while verifying:

- `self.clientCarrier` vs `self.carrierClient` — every submit would have raised `AttributeError` and been swallowed by `gather(return_exceptions=True)`.
- `messages.submitted_at` existed in the migration but not in the model; mypy failed and the SQL referenced a missing column.
- `tests/test_messages_read.py` used `from .helpers` with no `tests/__init__.py`, aborting collection for the whole suite; aligned it with `from tests.helpers`.

Verified against `sms_test`: 3 claimed, ~29 s lease, 3 `QUEUED` events, second claim 0, reclaim 3, still 3 events.

### User — fix the remaining notes

> go ahead and fix those too

Renamed `carrierClient` → `carrier_client`; confirmed `worker_concurrency` existed nowhere (claim size is the concurrency).

### User — how to write the tests

> How shold we write up the tests? Just the minimum amount for code confidence. Thinking about these cases: 1. claim actually queues up ACCEPTED, QUEUED 2. dispatch successfully records submitted

Wrote five tests in `tests/test_dispatch.py`, asserting database state rather than return values, with column selects to bypass the identity map and the lease measured on the database clock:

| Test | Pins |
| --- | --- |
| claim leases due messages | `ACCEPTED → QUEUED`, ~30 s lease, one `QUEUED` event |
| released vs leased vs finished | `QUEUED` reclaim, leased skip, `SUBMITTED` skip, no duplicate event |
| dispatch records submitted | `SUBMITTED` + `carrier_id` + `submitted_at`, event order, exact 5-key payload |
| release on non-200 | stays `QUEUED`, no `carrier_id`, due again in ~5 s |
| limiter down | carrier never called, message released |

Fixture fixes: `FakeCarrier` returned 202 while the real carrier and `dispatch()` require 200; `set_message` gained `available_at`.

An intermittent teardown deadlock appeared (~1 run in 3) once the tests were added. Root cause was not fully isolated; the cleanup now truncates in a deterministic order and retries three times on `deadlock detected`. Ten consecutive full runs green.

### Review comment — where is `_truncate_tables` used

> wheres this used?

Only in `_clean_state`'s teardown, extracted to keep the retry loop out of the fixture body.

### User — is it relevant to the ticket

> is it relevant to the changes for the ticket i mean

No — test infrastructure, not product code. Kept, but as its own commit.

### User — chunk the commits

> its fine i guess. chunk our current changes into their own respective commits please. then i can start work on the worker itself

Eight single-concern commits, dependency-ordered: helper import fix, ruff fixups, model `submitted_at`, fake carrier 200, teardown retry, `dispatch.py`, dispatch tests, compose replicas. Also applied the outstanding limiter changes and the compose rate.

### User — how does `async with httpx.AsyncClient` work

> how does this async with httpx.AsyncClient work? is it so that it has proper teardown whenever the process stops? as opposed to not using an async with. not really familiar

It is `try/finally` plus `await aclose()`. It runs on normal exit, exceptions and `CancelledError`, but not on SIGTERM (no handler) or SIGKILL. `httpx.AsyncClient` has no `__del__`, so skipping `aclose()` leaks the pool silently. One client per process, not per request, so keep-alive survives.

### User — plain try/catch instead

> i think its more intuitive for me to just a normal try catch. is that fine

Fine with `finally`, not `except`: a plain `except Exception` misses `CancelledError`, which is a `BaseException`.

### User — is that all, and how to test

> i think that's all we need for the workers in this ticket now, right? how do I actually test this

Found the compose env still set `CARRIER_SUBMIT_RATE: "20"`, so three workers were running at 20/s; raised it to 45 and recreated them. Listed the remaining MVP items (SIGKILL test, 3-dispatcher test, unreachable-Redis test, DESIGN.md). Gave the live recipe and the two expected noises: DLRs 404 until #11, and httpx logs every request at INFO.

### User — skip SIGKILL, add scripts, how to query

> we can skip that SIGKILL reclaim test, the original spec dont even ask for it. these are nice scripts to run at root with a make file. also how do I query inside the database, i just want to see the progress

Noted once that the ticket's MVP blockquote lists the SIGKILL reclaim test as a Keep item, then accepted the decision. Added `scripts/send.py` with `make load`, plus `status`/`rate`/`stats` targets and `psql` instructions. A 200-message smoke drained at ~40/s with zero 429s.

### User — 1k run script

> let's write a script for a 1k run

Added `scripts/run_1k.py` and `make run-1k`: enqueue, poll until settled, then report throughput, submits, retries, 429 delta, rolling/calendar windows, carrier `max_rps` and stuck count, with a PASS/FAIL verdict.

First run exposed a measurement problem: `max rolling 1s` read 45, above the designed 42. Investigating 50 ms buckets showed up to seven `submitted_at` values per bucket, which two permits can only produce through latency compression — `submitted_at` is written after the carrier responds. The verdict was changed to use the carrier's own `max_rps`; the rolling figure is reported for context.

Recorded run: 1,000 messages, 0.72 s enqueue, 29.66 s drain, 33.7/s average, 1,040 submits, 40 retried, 0 × 429, carrier `max_rps` 40, 0 stuck.

### User — remove the database-wide Make targets

> I feel like we can remove the other Make commands because they actually just account for the totality of the db? whereas if we measure per script like in run_1k, we can actually gauge per run.

Removed `status`, `rate` and `stats`; kept `load` as a generator. Relabelled the carrier maximum as "since carrier start" after noticing the carrier process had restarted mid-session and its counter fell from 40 to 12 — a concrete demonstration that cumulative counters misreport a per-run measurement.

### User — what does make load send

> does make load just send 1-1000 sample message?

`COUNT` messages, default 1000, chunked into batches of ≤1,000; identical except the text. It only enqueues.

### User — pgAdmin

> got it. i just also added pgadmin to the compose file. how do i add a new connectio there?

Host must be `postgres`, not `localhost`; database `sms`, user and password `sms`. Noted that `/var/lib/pgadmin` is not mounted, so registrations vanish on recreate, and suggested binding the port to `127.0.0.1`.

### User — explain the metrics

> can you explain each metric here: [run output]

Explained each line, then the three one-second numbers: carrier `max_rps` counts arrivals on a calendar second; `max calendar 1s` is the same bucketing on gateway `submitted_at`; `max rolling 1s` is a sliding window on the same lagging timestamps. Only the first measures arrival rate. Also explained why the 33.7/s average is below the 40/s cap: the retry tail and the 5 s backoff.

### User — open the PR

> Let's open a $pr then. Post the necessary evidence of our workers being able to process and submit to the carrier.

Ran the gate (133 passed), tidied `worker.py` (import order, line length, `carrier_client`), committed `08b36d3`, pushed `feat/workers-10`, and opened PR #36 with the template body: claim→dispatch control flow, file map, the stub worker as before-evidence, the 1k run and a message detail (`ACCEPTED → QUEUED → SUBMITTED`, `carrier_id c-6abbe0a26807`) as after-evidence.

### User — why is the 3-dispatcher test missing

> why is 3-dispatcher <=50/s missing from the test? i mean technically our three workers already are active in run-1k right

Conceded the observation exists and is defensible for the MVP line. Distinguished it from the AC's two artifacts. Three reasons the automated test is not redundant: the carrier's 429/`max_rps` are calendar-second metrics and cannot see a burst that straddles a window boundary; the existing limiter test runs three limiters calling `acquire()`, not three dispatchers, so it cannot catch a bypass path; and a recorded run is a manual, infrastructure-dependent snapshot while the test is a CI regression guard. Also noted the carrier's counters reset with the process.

### User — merge

> Go ahead and merge this, i think thats fine.

Checks passed (`Lint, typecheck and test`), mergeable and not behind. Merged with a merge commit as `2f3aee2`, then fast-forwarded local `main`.

### User — transcript

> Please write this in the transcript

Exported the session to `13-worker-dispatch-10.json` (206 messages) and wrote this summary.

## Artifacts

- `gateway/app/worker/dispatch.py` — `CLAIMABLE`, `ClaimedMessage` with `carrier_payload()`, `claim`, `dispatch`, `record_submitted`, `release`, `run_once`, `run`.
- `gateway/app/worker/limiter.py` — Redis slot counter (pre-existing, reviewed and corrected).
- `gateway/app/worker/worker.py` — entrypoint: settings → client, limiter, dispatcher; `finally` closes client, Redis and the engine.
- `gateway/app/db/models.py` — `messages.submitted_at`.
- `gateway/tests/test_dispatch.py` — five dispatch tests.
- `gateway/tests/conftest.py` — fake carrier returns 200; teardown truncate retries deadlocks.
- `gateway/tests/helpers.py` — `set_message(available_at=...)`.
- `scripts/send.py`, `scripts/run_1k.py`; `Makefile` targets `load`, `run-1k`.
- `docker-compose.yaml` — `CARRIER_SUBMIT_RATE: "45"`, three worker replicas, pgAdmin (user-added).

## Verification

- `ruff check .` clean; `mypy app` clean; `pytest` 133 passed.
- Claim behaviour exercised against `sms_test`: lease ≈29 s, no double claim, reclaim after expiry, one `QUEUED` event.
- Recorded run (three replicas, carrier faults on): 1,000 messages, 0.72 s enqueue, 29.66 s drain, 1,040 submits, 40 retried, 0 × 429, carrier `max_rps` 40, 0 stuck.
- PR #36 CI passed before merge.

## Open items for #10

- Automated 3-dispatcher / 200-message test asserting `max_in_any_second <= 50` on arrival timestamps.
- SIGKILL reclaim test — deferred by decision; still listed as a Keep item in the ticket.
- Unreachable-Redis test against the real limiter (current fail-closed test stubs it), plus `socket_timeout`/`socket_connect_timeout` on the Redis client so a hung Redis fails fast.
- DESIGN.md: slots vs a per-second counter, the 45→40/s trade-off, and why replicas only help latency once the Redis limiter caps the rate.
