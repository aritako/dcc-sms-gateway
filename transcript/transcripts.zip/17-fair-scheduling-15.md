# Session 17 — Fair tenant scheduling for #15

- **Date:** 2026-11-21 → 2026-11-22
- **Agent/model:** `opencode-go/deepseek-v4.1-flash` (high); final council at `deepseek-v4.1-flash`/max, `glm-5.3-flash`/max, `muse-spark-1.3-contributor`/xhigh
- **Goal:** Decide how #15 should schedule tenants, implement the smallest fair-claim slice, prove it under 10k + OTP load, review it, and merge it.
- **Outcome:** Equal-share per-claim tenant scheduling lives in `gateway/app/worker/scheduler.py`; `Dispatcher.claim` only leases the selected ids. 169 gateway tests pass. The 10k ShopFast + 288 Acme OTP run passed at p95 2.126s with 0 × 429. The final council approved 9/9/9. PR #42 merged as `ff353cf`.
- **Issues/commits:** [#15](https://github.com/aritako/dcc-sms-gateway/issues/15), [#13](https://github.com/aritako/dcc-sms-gateway/issues/13) (base, [PR #40](https://github.com/aritako/dcc-sms-gateway/pull/40)), [#20](https://github.com/aritako/dcc-sms-gateway/issues/20) (load script), [#22](https://github.com/aritako/dcc-sms-gateway/issues/22) (deferred DESIGN.md); `b22671a`, `44e3bb5`, `8c42ad9`, `05deb33`, `0649801`, merge `ff353cf`.
- **Complete export:** `17-fair-scheduling-15.json` (inside `transcripts.zip`)

## Transcript

### User

For issue 15, what kind of scheduling mechanism should we create? Can we use an external package to make things simpler? I feel like making our own round robin is quite the complexity.

### Assistant

Recommended no external package and no in-process round-robin. In a PostgreSQL queue the only cross-worker scheduling point is the claim query, so fairness belongs in `SELECT … FOR UPDATE SKIP LOCKED`.

Proposed the minimum shape:

- every active tenant's oldest due message is selected first;
- the remaining claim slots go to the globally oldest due work;
- `due_at = COALESCE(next_attempt_at, available_at)` preserves FIFO first attempts and retry order.

Assessed `pgqueuer`, `procrastinate`, `pgmq`, Celery/RQ/ARQ/Dramatiq, Hatchet and in-process DRR libraries. None provides tenant-fair dequeue over the existing `messages` table; adopting one would duplicate the queue and bypass the message state machine, ledger and DLR tables.

Also flagged a second-order p95 risk: `run_once` waits for the whole claimed batch, so a 2s ambiguous submit timeout delays that worker's next claim; three workers mitigate it.

### User

Alright, let's transfer this session to feat/retry-13 then work on a minimum example so we can have this round robin going.

### Assistant

Discovered PR #40 (`feat/retry-13`) was already merged into `main` at `d983ac1`. Moved the session to a new worktree on `feat/scheduling-15` based on updated `main` instead of the merged feature branch.

Implemented the first minimum:

- `active` CTE: tenants with due work, ordered by oldest due message;
- one locked head per tenant via `LATERAL … FOR UPDATE SKIP LOCKED`;
- `fill` CTE for the remaining slots;
- existing lease/`QUEUED`-event transaction unchanged.

Added two tests: a short Bank tenant against a Campaign backlog, and three concurrent workers claiming disjoint batches with both tenants present.

### User

how am i gonna review the changes if its on a new worktree man. we can do it in the main checkout here

### Assistant

Removed the temporary worktree, checked out `feat/scheduling-15` in the main checkout, moved the session back to the main repo, and re-ran the full suite there (165 passed at that point).

### User

What exactly did you add? Doesnt seem like scheduling logic to me, unless im wrong

### Assistant

Acknowledged that no scheduler object was added: the change was the scheduling *decision* inside `claim()`. Explained the `active` → `heads` → `fill` query and the difference between head-of-line fairness and equal-share DRR.

Was explicit about the limitation: with two equal backlogs the fill step is FIFO, so one tenant could get 19 of 20 slots and the other 1. The 3-worker test only asserted presence and disjointness, not a fair split.

### User

what would the equal share DRR look like? that seems to be the sensible option since we want a fast(er) single Bank OTP not lagging behind a 2000 message backlog

### Assistant

Implemented per-claim equal shares. With `K = claim_size` and `N = active tenants`:

```text
q = K // N
r = K % N
first r tenants by oldest head get q + 1 slots; the rest get q
```

Each tenant's share is locked FIFO in a `LATERAL … LIMIT quota FOR UPDATE SKIP LOCKED`; the `fill` CTE gives unused slots to the globally oldest work. This is work-conserving: a single Bank OTP consumes its one message immediately, and Bank's unused share goes to ShopFast.

Added tests for:

- equal backlogs → 2/2 with K=4;
- uneven batch → 2/1/1 across three tenants;
- N > K → four distinct tenants for four slots;
- three workers → 12 disjoint claims, 6/6 per tenant;
- a short tenant alongside a backlog;
- a due retry ordered ahead of a newer first attempt.

Ran the full suite: 168 passed.

### User

`$council` please deliberate these changes, is it acceptable and will it pass the throughput of 10k + OTP messages

### Assistant

Ran the 10k proof before starting the council, using the #20 load script from `feat/load-20` against the live three-worker stack bound to this branch:

```text
10,000 ShopFast + 288 Acme OTPs at 1/s
wall             296.1s
average submit   37.3/s
observed max     42/s
429 / 503 / 400  0 / 324 / 100
OTP p50 / p95    1.056s / 2.126s  (limit 3s, n=282 of 288)
terminal         10,288 / 10,288
billing          per-tenant ledger matches balance
result           PASS
```

The 6 OTPs that never reached `SUBMITTED` ended `FAILED` from injected permanent 400s; the p95 sample excludes them and the script warns about it. Raw log: `/tmp/opencode/load10k.log`.

Convened three read-only delegates:

- DeepSeek V4.1 Flash — 8/10;
- GLM-5.3-Flash — 9/10;
- Muse Spark 1.3 — 8/10.

No correctness bug was found. DeepSeek independently confirmed the running worker had this code and measured the claim query at ~7–13 ms on the 10k due set. Consensus caveats:

- the deferred N > K case is not full DRR: the same top-K tenants by oldest head can hold the prefix until their backlog drains;
- the batch barrier and unindexed coalesced due time are watch items;
- the 10k p95 has survivorship bias from the six failed OTPs and needs an explicit note in the #20 report.

Applied the round-1 documentation/test fixes: corrected the docstring’s lock/rotation wording, added remainder-attribution and due-retry-ordering assertions. Re-ran: 169 passed, ruff and mypy clean.

### User

go ahead and open the `$pr` please,, attach evidences of the performance

### Assistant

Pushed `feat/scheduling-15` and opened [PR #42](https://github.com/aritako/dcc-sms-gateway/pull/42) with the PR skill template:

- Summary of the equal-share algorithm and fill behavior;
- Before/after performance evidence (analytical global-FIFO before; the 10k run after);
- tests and 3-worker fairness result;
- merge danger: two-way door, dispatch-wide blast radius;
- council round 1 scores;
- the 10k caveat about the six injected failures.

Linked issue #15.

### User — PR review comment

`dispatch.py` L89: “is it possible to extract this to a new helper function, in worker/scheduler.py or something more appropriate”

### Assistant

Extracted the claim selection into `gateway/app/worker/scheduler.py`:

- `claim_query(claim_size)` builds the `active`/`ranked`/`selected`/`claimed`/`fill` query;
- `CLAIMABLE` moved there and is imported by `dispatch.py`;
- `Dispatcher.claim` now executes `claim_query(self.claim_size)` and keeps the lease, `UPDATE` and `QUEUED` event transaction.

Commit `0649801`. Re-ran 169 tests, ruff and mypy (40 files). Updated the PR body to point at `scheduler.py` and replied on the PR with the extraction note.

### User

`$council` … Alright, run one last `$council` then lets merge

### Assistant

Convened the final round at the skill’s final-round settings (`max` / `max` / `xhigh`). All three delegates confirmed the extraction was a pure move and approved merging:

| Seat | Round 1 | Round 2 |
| --- | --- | --- |
| DeepSeek V4.1 Flash | 8/10 | 9/10 |
| GLM-5.3-Flash | 9/10 | 9/10 |
| Muse Spark 1.3 | 8/10 | 9/10 |

No blockers. Round-2 findings left as post-merge polish: a narrower `CompoundSelect` return type, and the deferred persisted rotation cursor / expression index / batch-barrier tracking.

Updated the PR’s council table to both rounds, confirmed the check was green, merged PR #42 as `ff353cf`, unwatched it, and fast-forwarded local `main`.

### User

write in transcript brother

### Assistant

Exported this session to `transcript/17-fair-scheduling-15.json` and wrote this summary.

## Decisions

- No external queue/scheduler package. The PostgreSQL claim query is the scheduler.
- Fairness is per claim, not in process memory: one equal-share quantum per active tenant, then a global fill for unused slots.
- No schema change in the MVP. The persisted `last_claimed_at` cursor for >K tenants is deferred to the 50-tenant/DESIGN.md work.
- Claim selection is a pure query builder in `worker/scheduler.py`; the dispatcher owns leases, submits and status transitions.
- 10k + OTP evidence is a PASS at p95 2.126s, with the six injected-400 OTP failures named rather than hidden.

## Artifacts

- `gateway/app/worker/scheduler.py` — `claim_query` and `CLAIMABLE`.
- `gateway/app/worker/dispatch.py` — `Dispatcher.claim` delegates selection; lease/`UPDATE`/event transaction unchanged.
- `gateway/tests/test_dispatch.py` — six scheduling tests.
- [PR #42](https://github.com/aritako/dcc-sms-gateway/pull/42) — merged as `ff353cf`.
- 10k load log (local): `/tmp/opencode/load10k.log`.

## Tool activity

- `gh issue view 15`, `gh issue view 13`, `gh issue view 20`, `gh pr view 40` — scope and dependency checks.
- `git log`, `git diff`, `git worktree`, `git switch`, `git pull`, `git push` — branch/worktree management.
- `docker compose ps`, `docker exec` — confirmed the live three-worker stack ran this branch via bind mount/watchfiles.
- `uv run pytest`, `uv run ruff check`, `uv run mypy` — 169 passed, clean, clean.
- `scripts/load_test.py 500` (smoke, p95 1.695s) and `scripts/load_test.py 10000` (PASS, p95 2.126s) from the #20 worktree.
- `delegate_task` × 6 — council rounds 1 and 2.
- `pull_request_create`, `pull_request_update`, `pull_request_respond`, `pull_request_merge`, `watch_pull_request`, `unwatch_pull_request` — PR #42.
- `opencode session export "$OPENCODE_SESSION_ID"` — this raw transcript.
