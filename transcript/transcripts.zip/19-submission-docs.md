# Session 19 — Submission artifacts #22 and DESIGN review

- **Date:** 2026-11-22
- **Agent/model:** `opencode-go/deepseek-v4.1-flash` (high)
- **Goal:** Finish issue #22's submission artifacts in a fresh `docs/submission-22` worktree: test matrix, submission checklist, README links, and a read-only review of DESIGN.md.
- **Outcome:** `TEST_MATRIX.md` maps all seven mandated tests to files, exact test names and commands; `SUBMISSION.md` is the reviewer checklist; README links both. `make test-all` passed 176 gateway + 12 carrier tests, lint/typecheck clean. Commit `a5af0f9` shipped as PR #45, merged as `ad4ae63`. DESIGN.md was reviewed twice and never edited; at review time it answered all four questions but still lacked the design-note sections and the "how do you prove it" evidence. The user then expanded and committed DESIGN.md themselves (`8776b0a`, `7d87d46`, `25b6d33`) after this review.
- **Issues/commits:** [#22](https://github.com/aritako/dcc-sms-gateway/issues/22), [PR #45](https://github.com/aritako/dcc-sms-gateway/pull/45); `a5af0f9`, merge `ad4ae63`.
- **Complete export:** `19-submission-docs.json` (inside `transcripts.zip`)

## Transcript

### User

T3 brief: fresh worktree on `docs/submission-22` from `origin/main`. Finish #22, docs-only, no code. Do not edit `DESIGN.md` (the user is writing it separately), do not edit raw transcripts, do not rewrite README (#44 just cleaned it); at most add a docs link. Read AGENTS, #22, README, the main-checkout DESIGN, Makefile, CI, load output, transcript README and both test suites. Deliver `TEST_MATRIX.md` for the seven mandated tests (encoding/segments; idempotency one message/one charge; early + duplicate DLR; concurrent overdraw; 429/503 retried vs 400 not; bad/missing DLR signature; cross-tenant 404) with verified names, a concise `SUBMISSION.md`, a read-only DESIGN review, README link checks, no transcript zip, and commit but do not merge. Report mapping count, DESIGN gaps, test result and blockers.

### Assistant

Read the brief's sources: `AGENTS.md`, issue #22, README, the 24-line DESIGN draft (only Q1 and Q4 answered), `Makefile`, `.github/workflows/ci.yml`, `transcript/README.md`, the captured 10k output, and every gateway/carrier test file.

Facts established before writing:

- 176 gateway tests and 12 carrier tests exist; the service stack was already up (Postgres, Redis, API, carrier, three workers).
- Test names were confirmed with `pytest --collect-only`, not guessed.
- The 429 retry path has no dedicated gateway test: `dispatch.py:174` classifies every non-400 status as transient, and #13's MVP path explicitly deferred a 429-limiter unit test. The carrier's `test_limit_is_shared_by_every_caller` covers 429 emission.

Wrote both artifacts and made three link-only README edits:

- `TEST_MATRIX.md` — seven rows plus per-scenario test lists and commands, a supporting-suites table, and an honest note about the deferred 429 test.
- `SUBMISSION.md` — what is included, run steps, test commands, load proof, transcript zip command/status, DESIGN link, secrets note, known limitations (no dashboard/SSE/webhooks, bonuses #23–#27, in-memory carrier dedupe), and a ticket checklist that leaves DESIGN and the zip unchecked.
- `README.md` — replaced the issue-#22 link with `TEST_MATRIX.md`, added `SUBMISSION.md`, and pointed the CI sentence at the matrix.

Verification run:

```text
make test-all      176 gateway + 12 carrier passed
per-row commands   19 / 8 / 12 / 8 / 13 / 11 / 9 passed
make lint          clean
make typecheck     clean (41 files)
/healthz           200
make smoke         4/4 PASS
```

All relative links resolved except `DESIGN.md`, which is not in the branch. Committed `a5af0f9` and opened draft PR #45 with the PR template, noting the missing DESIGN and the deferred 429 test.

### User

“sure let's merge that for now while i do my DESIGN.md”

### Assistant

Checked PR #45: draft, `CLEAN`, both CI check runs successful. Marked it ready and merged with a merge commit, matching the repo's history (`ad4ae63`). Fast-forwarded the main checkout to the merge; the untracked DESIGN.md was not touched. Left the branch in place, as earlier merged branches were.

### User

“how is my current DESIGN.md? is it satisfactory”

### Assistant

Re-read DESIGN.md (now 62 lines, 1,641 words) and checked its claims against the code: scheduler claim query, lease and sweep constants, limiter slots, refund paths, schema constraints.

Verdict: all four questions are now answered and Q3 (fairness) is strong and matches `scheduler.py`. But the file is not yet satisfactory as the #22 deliverable:

- **Q2 proof gap:** the question asks how exactly-once is proven; the answer lists mechanisms but no tests. Should point at concurrent idempotency, same-`message_id` timeout retry, duplicate-DLR no-op, exactly-once refund and carrier dedupe tests.
- **Refund error:** refunds are described as 400 or six exhausted attempts. Ambiguous-only exhaustion ends `FAILED` with `billing_state=REVIEW` and no refund.
- **Retry ordering error:** “a retry does not jump ahead of new work” is false; claims order by `COALESCE(next_attempt_at, available_at)`, so a due retry can precede a newer first attempt (`test_claim_orders_a_due_retry_before_a_newer_first_attempt`).
- **Missing acceptance sections:** schema/transactions/locks/constraints detail, Postgres-queue-vs-Redis rationale, timeout/refund policy including REVIEW, full status ordering, idempotency semantics, rate-limit window boundary (50 ms Redis slots, ≤42/s), and one line per deferred bonus #23–#27.
- **Polish:** ~3 pages against the 1–2 page target; questions should be `###` under `## Questions`; a few typos (“Out right”, “sucessful”, doubled negative in Q1).

This review applies to the 62-line/1,641-word draft read at that moment. Afterward the user expanded DESIGN.md to roughly 95 lines with new `Core design` (Carrier, Gateway, Workers, Postgres or Redis, What I would add), `Data Models`, the four questions and an `AI Usage` section, and committed it on `main` (`8776b0a`, `7d87d46`, `25b6d33`). That newer version was not re-reviewed in this session.

### User

“did you change anything? please dont change until i say so”

### Assistant

No. The review was read-only (`read`, `wc`, `git status`, code greps). `M DESIGN.md` in the working tree is the user's own in-progress edit. No further changes made.

### User

“write this in transcript please, if we havent already.”

### Assistant

Confirmed session `ses_e0069443fffebdah7hnVIl6f3X` had no export; 18 transcripts existed. Exported the complete session to `transcript/19-submission-docs.json` from the main checkout and wrote this summary. The export covers the conversation through this request. Raw files stay git-ignored; no zip was built and nothing transcript-related was committed. The harness restarted once during the export; the JSON and this Markdown were written after the restart.

## Tool activity

- `gh issue view 22`, `gh issue list`, `gh issue view` for #6/#7/#11/#13/#14 — scope and mandated-test wording.
- `grep`/`read` across `gateway/tests`, `carrier/tests`, `scheduler.py`, `dispatch.py`, `dlr.py`, `limiter.py`, `settings.py`, `models.py` — verify every claim and test name.
- `uv run pytest --collect-only` — confirm node names and the 176/12 counts.
- `make test-all`, `make lint`, `make typecheck`, per-file `uv run pytest`, `curl /healthz`, `make smoke` — green.
- `git add/commit` `a5af0f9`; `git push -u origin docs/submission-22`.
- `gh pr view/ready/merge 45`; fast-forwarded main to `ad4ae63`.
- `opencode session export "$OPENCODE_SESSION_ID" > transcript/19-submission-docs.json`; validated the JSON (58 messages, 423 KB).
