# Session 18 — Load test #20: 10k campaign, OTP p95 and billing audit

- **Date:** 2026-11-21 → 2026-11-22
- **Agent/model:** `opencode-go/deepseek-v4.1-flash` (high); council at `deepseek-v4.1-flash`/high, `glm-5.3-flash`/high, `muse-spark-1.3-contributor`/high
- **Goal:** Implement ticket #20's load script, run the official 10k ShopFast + Acme OTP proof, open a PR, run a council review, and merge.
- **Outcome:** `scripts/load_test.py` and a captured 10k run live on `main`. The final run passed at OTP p95 `2.341s`, all 10,291 messages terminal, both tenants reconciled, and 0 carrier 429s. Council finished 3 rounds at 9/9/9. PR #43 merged as `9b33b73`.
- **Issues/commits:** [#20](https://github.com/aritako/dcc-sms-gateway/issues/20), [PR #43](https://github.com/aritako/dcc-sms-gateway/pull/43); `85121b9`, `b512181`, `e839a11`, `46fa325`, `6915bc6`, merge `9b33b73`.
- **Complete export:** `18-load-test-20.json` (inside `transcripts.zip`)

## Transcript

### User

Ticket #20 brief: implement the real load script in a fresh worktree on `feat/load-20` based on `origin/main`. It must send 10,000 ShopFast messages in batches of at most 1,000 plus one Acme OTP per second, wait for final states with a timeout longer than 10 minutes, report wall time/carrier submit rate/OTP accept-to-SUBMITTED p50+p95/final counts/carrier 429-503-400-timeouts/max rate, assert p95 ≤3s, reconcile per-tenant billing exactly, print human + JSON output, handle API errors, and support a small COUNT smoke run. Do not touch worker/fairness code (#15), README (#22), frontend, or webhooks. Check whether #15 is merged; if not, smoke only and report the official 10k as pending.

### Assistant

Read `AGENTS.md`, issue #20, the existing scripts, API models, worker dispatch, carrier `/stats`, seed data and migrations. Confirmed #15 was **not** merged: no PR/branch existed and the claim order was still `due_at, id`.

Implemented `scripts/load_test.py` as an async httpx driver:

- `send_campaign`: `COUNT` messages in batches of at most 1,000, unique `client_ref`s and idempotency keys.
- `otp_loop`: one Acme OTP per second, concurrent with the campaign, continuing until the campaign settles.
- `wait_terminal`: terminal-state polling with a default 900s timeout.
- OTP latency from persisted `message_events` (`ACCEPTED` → `SUBMITTED`), not client timing.
- Billing audit read directly from PostgreSQL: lifetime `balance == opening + SUM(ledger)`, one charge per message, refund checks, duplicate `client_ref`s.
- Human + JSON output and nonzero exit on p95/billing/terminal/API violations.

The running local stack was on schema `c3a8f1d4e6b2`; batch send failed on the missing `billing_state` column. Applied the already-committed `f7b2c9d14e60` migration and re-ran the seed. No schema files changed.

Smoke `COUNT=200` confirmed the rest of the script worked but failed the p95 assertion at `4.855s`, as expected before #15. With `OTP_P95_LIMIT=10` all other checks passed. Committed `85121b9` (after an earlier rebase; the first local commit hash changed).

### User

“fair scheduler is now merged. rebase and run the 10k”

### Assistant

Fetched `origin/main` at `ff353cf` (`feat/scheduling-15` merge), rebased `feat/load-20`, and fast-forwarded the local main checkout so the running stack used the merged scheduler.

Ran the full proof:

```text
10,000 ShopFast + 285 Acme OTPs
wall             293.5s
average submit   37.7/s
observed max     42/s
429 / 503 / 400  0 / 322 / 90
OTP p50 / p95    1.064s / 2.056s  (n=281 of 285)
terminal         10,285 / 10,285
billing          run ledger -843 Acme, -29,742 ShopFast
result           PASS
```

Captured the run in `scripts/load-output/2026-11-22-10k.txt` and committed `b512181`.

### User

“open a $pr then have a $council review please”

### Assistant

Pushed `feat/load-20`, opened [PR #43](https://github.com/aritako/dcc-sms-gateway/pull/43) with the PR skill template, and started three read-only council delegates.

### Council round 1

- DeepSeek V4.1 Flash — 7/10.
- GLM-5.3-Flash — 6/10.
- Muse Spark 1.3 — 8/10.

Main findings:

- The run message set came from API response ids, so a lost response plus broken idempotency could hide an orphaned duplicate batch.
- Billing was lifetime-scoped in the evidence; the captured tenant ledgers included earlier runs, which made them look impossible for this 10k alone.
- Missing OTPs were only a warning, not a first-class gate.
- The captured run’s headline/max-rate metrics mixed instruments.
- No tests or CI coverage for the script.
- `DRAIN_TIMEOUT <= 600` blocked short CI smoke runs.

### Assistant

Confirmed from PostgreSQL that the captured lifetime balances were cumulative, while this run’s own ledger was exactly `Acme -843` and `ShopFast -29,742`. Fixed the real issues:

- Read run ids back from the database by `client_ref` for campaign and OTPs; compare response ids with DB ids and fail on mismatches.
- Add run-scoped billing deltas and per-message refund amount/eligibility checks.
- Expose unsubmitted OTPs and require at least 90% sample coverage for p95.
- Add per-run max submit rate from `submit_attempts`; keep carrier lifetime max separate.
- Allow short smoke timeouts; start the drain deadline after enqueue.
- Add unit tests for the pure helpers and a DB-backed audit test.
- Add CI lint/typecheck steps for the script.
- Add a `load-test` Make target.

Reran the 10k (`294.9s`, p95 `2.040s`) and recaptured the evidence. Committed `e839a11` and pushed.

### Council round 2

- DeepSeek V4.1 Flash — 8/10.
- GLM-5.3-Flash — 9/10.
- Muse Spark 1.3 — 8.5/10.

Remaining should-fixes:

- A concurrent smoke refund landing after the billing snapshot could false-fail a correct run.
- Reconciliation errors only said “billing reconciliation failed” without tenant/amount detail.
- The OTP drain reused the campaign deadline.
- The database-backed test did not yet cover the audit SQL.
- The PR evidence summary was stale.

### Assistant

Fixed the isolation assumption by separating:

- `accounting_ok`: balance delta == ledger delta over the run window, independent of who wrote the ledger.
- `run_ledger`: reporting only; any other ledger activity becomes an `other_ledger` warning.

Also:

- Named tenant and amounts in reconciliation errors.
- Gave the OTP phase its own deadline.
- Added response-id vs DB-id set checks for both flows.
- Reported `billing_state='REVIEW'` rows as a warning.
- Added a database-backed test that seeds a charged batch, reads ids by `client_ref`, runs the audit, then duplicates the refs and asserts failure.
- Added local `make lint`/`make typecheck`/`load-test` wiring.
- Recaptured the 10k at p95 `2.341s`.

Committed `46fa325` and pushed.

### Council round 3

- DeepSeek V4.1 Flash — 9/10.
- GLM-5.3-Flash — 9/10.
- Muse Spark 1.3 — 9/10.

No blockers and no outstanding should-fixes. Remaining notes were cosmetic. Applied the final small follow-up: a named `missing_messages` error, zero-price refund guard, and a price-independent test assertion. Committed `6915bc6`, pushed, and updated the PR description with the 3-round council table and final evidence.

### System

PR #43 check `Lint, typecheck and test` passed on `6915bc6`.

### User

“let's just merge this thing”

### Assistant

Merged PR #43 into `main` with a merge commit. Verified `origin/main` at `9b33b73` (`Merge pull request #43 from aritako/feat/load-20`). CI was green on the merged head.

### User

“write in the transcript please”

### Assistant

Exported this session to `transcript/18-load-test-20.json` and wrote this summary in the main checkout on `main`.

## Final evidence

```text
run              load-20261121T172532Z-ce183cdc
campaign         10,000 ShopFast messages, 10 × 1,000
OTPs             291 Acme OTPs at 1/s
wall             300.1s
enqueue          7.9s
average submit   37.0/s
observed max     42/s (rolling 1s; carrier fixed-second max 42/s)
429 / 503 / 400  0 / 315 / 87
timeouts         115
OTP p50 / p95    0.993s / 2.341s  (n=290 of 291 submitted)
terminal         10,291 / 10,291
billing          run ledgers -870 Acme, -29,742 ShopFast
                 lifetime identities hold; 0 duplicate refs; 0 wrong charges/refunds
checks           OTP p95 PASS, OTP samples PASS, terminal PASS, billing PASS
```

## Decisions

- The database is the source of truth for a run’s message set; API response ids are only cross-checked.
- Billing separates the lifetime identity from the run window: balance delta must equal ledger delta, while `run_ledger` is run-scoped reporting.
- OTP p95 is measured from persisted `ACCEPTED` and `SUBMITTED` events, over submitted OTPs, with a 90% sample-coverage gate.
- The default drain timeout remains 900s (>10 min); short overrides are allowed for smoke runs.
- A clean 10k proof is a PASS at p95 2.341s with 0 carrier 429s.

## Artifacts

- `scripts/load_test.py` — campaign + OTP driver, drain, latency, carrier and billing checks.
- `scripts/load-output/2026-11-22-10k.txt` — captured final run.
- `gateway/tests/test_load_script.py` — pure-helper and DB-backed audit tests.
- `.github/workflows/ci.yml` — lints/typechecks the load script.
- `Makefile` — `load-test` target and local lint/typecheck coverage.
- [PR #43](https://github.com/aritako/dcc-sms-gateway/pull/43) — merged as `9b33b73`.

## Tool activity

- Read `AGENTS.md`, issue #20, `scripts/{run_1k,send,smoke}.py`, gateway models/reads/worker/carrier, README, Makefile, Compose and CI.
- Added `scripts/load_test.py`; ran ruff and mypy; ran `COUNT=200`, `COUNT=50`, and multiple `COUNT=10000` load runs against the local three-worker Compose stack.
- Applied migration `f7b2c9d14e60` and re-ran `app.seed` on the local dev database.
- Rebased onto `ff353cf`; committed `85121b9`, `b512181`, `e839a11`, `46fa325`, `6915bc6`.
- Pushed `feat/load-20`, opened PR #43, ran 3 council rounds via delegated read-only reviewers.
- Ran `make lint`, `make typecheck`, and the gateway suite (176 passed).
- Merged PR #43 as `9b33b73`; exported this session.
