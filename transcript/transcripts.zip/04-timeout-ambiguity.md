# Session 04 — Carrier timeout semantics and ambiguity

- **Date:** 2026-11-19
- **Agent/model:** opencode-go/deepseek-v4.1-flash
- **Goal:** Clarify what the gateway should return when the mock carrier's 1% timeout case ends up accepting and delivering the message, and check the proposed `408` implementation against issue #3 and the assignment brief.
- **Outcome:** Interpretation resolved. The carrier timeout is a slow success, not an error; the tenant never sees a timeout because the send API is asynchronous. No code was changed. Follow-up identified: the carrier's timeout branch currently sleeps then raises `504`, which must become "accept, schedule DLR, sleep, return 200"; the current handler also has a broken `from fastapi.responses` import and uses sequential random draws that skew the configured fault rates.
- **Issues/commits:** [#3](https://github.com/aritako/dcc-sms-gateway/issues/3), [#13](https://github.com/aritako/dcc-sms-gateway/issues/13)
- **Complete export:** `04-timeout-ambiguity.json` (inside transcripts.zip)

## Transcript

### User

Asked, based on issue #3 and the attached assignment PDF, what should be returned to the user when 1% of submitted requests time out after 5 seconds but the carrier still accepts and delivers. Proposed returning a timeout to the client while still sending:

```python
if random.random() < p_timeout:
  # accept and deliver
  raise HTTPException(status_code=408, detail="REQUEST_TIMEOUT")
```

### Assistant

Explained that two separate HTTP conversations were being conflated:

- **Tenant → gateway:** `POST /v1/messages` is asynchronous by design. It returns quickly with a message ID and `ACCEPTED`; the send happens in the background. By the time a worker calls the carrier, the tenant's request has already been answered, so a carrier timeout cannot and must not surface as `408`/`504` to the tenant.
- **Gateway worker → carrier:** the carrier does not return a timeout. Per the assignment and issue #3, the timeout branch sleeps ~5s, accepts the message internally, schedules a DLR, then eventually returns 200. The timeout is observed client-side by the gateway's HTTP client using a timeout shorter than 5s. That client-side read timeout is the ambiguous case.
- `408 Request Timeout` is semantically wrong regardless; a gateway upstream timeout would be `504 Gateway Timeout`, but neither belongs on the async send API.
- The gateway handles ambiguity by recording the attempt as ambiguous, keeping the message `QUEUED`, not refunding, and retrying with the same `message_id`. Carrier idempotency returns the same `carrier_id` and records no second delivery. If every attempt is ambiguous, the message becomes `FAILED` with `billing_state=REVIEW` and no automatic refund. Late DLRs are parked and never regress status.
- Implementation notes: the carrier must record acceptance and schedule the DLR **before** sleeping, so a client disconnect cannot drop the side effect; outcome classification should use a single draw so 3%/1%/1% are exact. The current `carrier/app/submit/controller.py` sleeps then raises `504`, which simulates a slow failure and never exercises dedupe.

### User

Summarized the understanding as: be optimistic to the caller of `/submit`, simulate async logic by timing out after 5 seconds, retry, and eventually succeed.

### Assistant

Corrected that the retry is not the carrier's. Only the carrier's timeout branch is optimistic; 429/503/400 remain honest failures, and the carrier only dedupes on `message_id`. The worker/gateway owns the retry: it times out, classifies the attempt as ambiguous, keeps the message `QUEUED`, and retries with the same `message_id`. The carrier's DLR is scheduled from acceptance, so it can arrive before or after the retry response; the monotonic state machine must handle both without regressing `DELIVERED`. Net tenant effect: one SMS, one charge, `DELIVERED`.

### User

Asked to write the discussion to the transcripts.

## Tool activity

- Read issue #3 (`gh issue view 3`) — carrier submit contract, timeout-still-accepts AC, dedupe AC, test controls.
- Attempted to read the attached PDF directly; the model could not ingest PDF input, so extracted text with `uv run --with pypdf` to `/tmp/opencode/assignment.txt` and read the assignment requirements.
- Read issue #13 — retry/timeout classification, ambiguous attempts, `billing_state=REVIEW`, no refund on ambiguity.
- Inspected `carrier/app/submit/controller.py` and confirmed the current timeout branch raises `504` after sleeping.
- Exported this session with `opencode session export "$OPENCODE_SESSION_ID"` into `transcript/04-timeout-ambiguity.json`.
