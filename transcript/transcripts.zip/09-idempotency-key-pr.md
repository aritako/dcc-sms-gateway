# Session 09 — Idempotency-Key MVP and PR

- **Date:** 2026-11-20
- **Agent/model:** opencode-go/deepseek-v4.1-flash
- **Goal:** Implement the minimum working example of ticket #7 (`Idempotency-Key` for message sends), address review comments, run a council review, open a PR, and record this session.
- **Outcome:** One migration/table, one small service, wiring only on `POST /v1/messages`, the six required tests plus empty/oversized-key and last-cents race regressions. `ruff`, `mypy` and all 86 tests pass. PR #33 merged as `2716b7a`; issue #7 closed. Next recommended ticket is #8.
- **Issues/commits:** #7; commits `50e28a5`, `0d3d37b`, `c9b12d4` on `feat/idempotency-07`, squash-merged as `2716b7a`; PR [#33](https://github.com/aritako/dcc-sms-gateway/pull/33).
- **Complete export:** `09-idempotency-key-pr.json` (inside transcripts.zip)

## Transcript

### User

Implement a minimum working example of ticket #7, “Idempotency-Key for message sends”, in a fresh worktree on branch `feat/idempotency-07` based on `origin/main`.

The brief was explicit:

1. One Alembic migration and one table `idempotency_keys` with `tenant_id`, `key`, `request_hash`, `response_status`, `response_body` (JSON/JSONB) and `created_at`; FK to tenants; `UNIQUE (tenant_id, key)`; no TTL, no method/path columns.
2. One small helper/service: canonicalize `method + path + canonical JSON` (sorted keys, stable separators), hash it, look up/replay the stored snapshot, store only 2xx, handle the unique-constraint race.
3. Wire only `POST /v1/messages`: unchanged without a key; replay same key/hash; `409 IDEMPOTENCY_KEY_REUSED` for same key/different hash; concurrent duplicates serialize to one message/charge; only 2xx stored so a 402 can be retried after top-up.
4. Minimal tests for same request twice, different body, concurrent duplicates, two tenants with the same key, 402 → top-up → same key, and the stored snapshot containing status and body.
5. No TTL cleanup, batch (#8), admin send, dashboard, generic middleware/decorator layer, or refactor of #6.
6. Follow existing style: two-space indent, type hints, async SQLAlchemy, Alembic, pytest.

Verification required `ruff`, `mypy` and the gateway test suite. Commit on the branch, do not merge, and do not open a PR unless explicitly asked.

### Assistant

Read `AGENTS.md`, issue #7, and the current #6 implementation (`controller.py`, `handler.py`, `models.py`, `billing.py`, `deps.py`, tests and migrations).

Implemented:

- Migration `e40134aacff4_idempotency_keys.py` with a composite primary key `(tenant_id, key)`, which is also the required uniqueness constraint and avoids adding a surrogate `id`.
- `IdempotencyKey` model with `response_body` as `JSONB`.
- `IdempotencyService` in `app/core/idempotency.py`: canonical SHA-256 request hash, tenant-scoped lookup, snapshot store that flushes so a duplicate key raises `IntegrityError` at the right point.
- Controller wiring: no key → existing path; same hash → replay stored status/body; different hash → 409 with no writes; on the unique-constraint race, roll back the loser’s message/event/charge, re-read the winner and replay it.
- Six idempotency tests in `tests/test_messages.py`, plus test-helper changes for a second tenant/API key and idempotent price seeding.
- A short `gateway/README.md` note documenting the header and the 2xx-only policy.

Verification: `ruff` clean, `mypy` clean (24 files), 83 tests passed. The migration was upgraded to head and downgraded to base on a scratch database.

Committed as `971b0d3 feat(gateway): replay idempotent message sends`.

### User

Review comment on `controller.py` L21: “can transfer this to the handler i believe.”

### Assistant

Moved the module-level `_replay` helper into `MessagesHandler.replay`, next to the existing `error_response`, and reused `error_response(409, "IDEMPOTENCY_KEY_REUSED")` for the hash mismatch. The controller now calls `handler.replay(...)`; the unused `IdempotencyKey` import was removed.

Checks still passed with 83 tests. Amended the local commit to `d90b72b`.

### User

Review comment on `controller.py` L17: “whats this for?” (`SEND_PATH`).

### Assistant

Explained that it supplied the path component of the canonical idempotency hash. Because `/v1` + `/messages` is mounted in `main.py`, the route decorator in this controller is empty, so the constant duplicated the mounted path.

Removed it: the fingerprint now uses the actual `request.method` and `request.url.path`, so it cannot drift from the route. Checks passed with 83 tests. Amended the local commit to `ce68e7d`.

### User

“run a $council to deliberate these changes please, if it is the minimum work required”

### Assistant

Convened three read-only council delegates from the `opencode-go` provider: DeepSeek V4.1 Flash, GLM-5.3-Flash and Muse Spark 1.3. Round 1 scores were 9/10, 9/10 and 8/10. All three said the implementation was the minimum working example.

The only functional finding was an unbounded `Idempotency-Key`: a multi-KB key could overflow the Postgres btree index entry limit and return an unhandled 500, with no data corruption. Fixed with `max_length=255` on the header and a regression test asserting a 256-character key returns 422 with zero messages/events/charges. That took the suite to 84 passing tests.

Round 2 (final, higher reasoning effort) scored 9/10, 9/10 and 9/10 with no blockers or majors. The remaining items were recorded, not fixed, to avoid scope creep: race-test path nondeterminism, the broad `IntegrityError` catch, redundant fingerprint guards needed for mypy, README wording, missing OpenAPI 409 documentation, the top-up test’s direct balance update, and empty-key handling.

The final local head became `50e28a5`.

### User

“go ahead and PR this, then write on the transcript”

### Assistant

Pushed `feat/idempotency-07` to `origin`, opened [PR #33](https://github.com/aritako/dcc-sms-gateway/pull/33) against `main` using the repo’s PR template, and included the two-round council table in the description and `Closes #7`. Linked the PR to this thread.

Exported this session to `transcript/09-idempotency-key-pr.json` from the main checkout on `main` and wrote this summary. Raw transcript files are ignored by Git; only the cumulative `transcripts.zip` will be committed at submission.

### User

PR #33 review: request changes. The key was written at the end of the transaction instead of being reserved at the start. A concurrent duplicate therefore did the full send before discovering it lost. With a tenant that could afford exactly one message, the loser could get `402 INSUFFICIENT_BALANCE` even though the winner had accepted, charged and queued the message — violating the same-key replay guarantee.

The requested fix: add the last-cents race test first; reserve the key before any work using `INSERT ... ON CONFLICT DO NOTHING`; return the existing row and replay it, or `409` for a different hash; make `response_status`/`response_body` nullable until completion with a `(both null) = (both non-null)` check constraint; replace `store()` with `claim()` and `complete()`; add `min_length=1` so an empty header is a `422`; and fix the 402 test’s top-up to write a CREDIT ledger row instead of updating the balance directly.

### Assistant

Added `test_concurrent_duplicates_replay_even_when_the_balance_runs_out` first. With five concurrent duplicates and a 3¢ balance it failed 3/3, returning `402` alongside the accepted response.

Then changed the flow to reserve-first:

- `IdempotencyService.claim()` inserts the key with `ON CONFLICT DO NOTHING` as the first write. Duplicates block on the composite primary key before quoting or charging, then `find()` the winner’s committed row and replay it.
- `IdempotencyService.complete()` fills `response_status`/`response_body` only on the 2xx path, in the winner’s transaction.
- The response columns are nullable until completion, guarded by `ck_idempotency_keys_response_complete`; the unmerged migration was edited in place.
- `422`/`402` roll back the reservation, so rejections are never stored and the key can be retried after top-up.
- `Idempotency-Key` now has `min_length=1`, so an empty header returns `422` instead of silently disabling idempotency.
- `handler.replay()` asserts the completed snapshot, and the 402 test top-up now writes a CREDIT ledger row via `_top_up`, preserving `balance = opening_balance + ledger_sum`.

Results: 86 tests pass; the last-cents race test passes 10/10; `ruff` and `mypy` are clean; migration `upgrade head` + `alembic check` + `downgrade base` pass on a scratch database. Committed as `0d3d37b`, pushed, and updated the PR description to the reserve-first flow.

### User

Final review comments on PR #33: omit the two inline rollback comments; rename the `idempotency` service instance to `idempotencyService`; and consider whether `replay` really belongs on `MessagesHandler` rather than the idempotency service.

### Assistant

Removed both rollback comments. Kept the requested `idempotencyService` instance name. Moved `replay` from `MessagesHandler` to `IdempotencyService.replay`, so the service owns the stored-row hash check, the 409, and the completed snapshot, while the handler only accepts messages and builds generic error responses.

Verified with `ruff`, `mypy` and all 86 tests. Committed as `c9b12d4`, pushed, and updated the PR body’s file tree. No behavior change.

### User

“Alright lets merge. What should we work on next after merging”

### Assistant

Merged PR #33 with a squash commit. `main` is now at `2716b7a feat(gateway): replay idempotent message sends (#33)` and issue #7 is closed (the PR body had `Closes #7`).

Next, per the issue dependency order, the lowest unblocked ticket is **#8, “Batch send up to 1,000 messages”**. Its only blockers were #6 and #7, both now closed. The MVP scope is `POST /v1/messages/batch`, 1–1,000 items with all-or-nothing validation, one aggregate debit with a charge row per message, `202` with `batch_id`, batch-scoped idempotency, and boundary/invalid/insufficient/replay tests. It should use a bulk insert and defer the `<2s` performance assertion and `batch_id` index.

**#10, “Worker dispatch”**, is also unblocked now (#2, #3 and #6 are closed) and could run in parallel, but #8 is the lower ticket and the default next step. (#9 is blocked by #8; #11, #13, #15 and the dashboard tickets remain behind the worker/DLR chain.)

## Tool activity

- Read `AGENTS.md`, fetched issue #7, inspected the #6 controller/handler/models/billing/deps/tests/migrations.
- Generated Alembic revision `e40134aacff4`, then wrote the idempotency table migration.
- Added `IdempotencyKey` and `IdempotencyService`; wired the controller and moved replay into the handler after review.
- Ran `uv run ruff check .`, `uv run mypy app`, and `uv run pytest -q` throughout; final result: 84 passed, mypy clean on 24 files.
- Verified migration `upgrade head` and `downgrade base` on a scratch Postgres database.
- Ran two council rounds with three `delegate_task` reviewers each (DeepSeek V4.1 Flash, GLM-5.3-Flash, Muse Spark 1.3).
- Committed, amended after each review comment and the council fix, then pushed and opened PR #33 with `gh pr create`.
- Linked the PR with `link_pull_request` and exported the session with `opencode session export`.
- Reproduced the post-PR 402 race with the new test (failed 3/3), downgraded `sms_test` one revision, edited the unmerged migration in place, and reran the suite (86 passed).
- Committed the reserve-first fix as `0d3d37b`, pushed it, updated the PR body with `gh pr edit`, and re-exported the session transcript.
- Applied the final review comments (drop rollback comments, keep `idempotencyService`, move `replay` into the service), committed `c9b12d4`, pushed, and re-exported the transcript.
- Merged PR #33 with `gh pr merge 33 --squash` (squash commit `2716b7a`), fast-forwarded `main`, confirmed issue #7 closed, and inspected the open issue dependency graph to select ticket #8 as the lowest unblocked next step.
