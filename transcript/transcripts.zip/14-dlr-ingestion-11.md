# Session 14 — DLR ingestion (#11), council review and terminal-status load tracking

- **Date:** 2026-11-21
- **Agent/model:** opencode-go/deepseek-v4.1-flash (OpenCode / T3 Code)
- **Goal:** Implement issue #11's MVP path — signed carrier DLR ingestion, a durable receipt inbox, a monotonic status machine, early-DLR reconciliation, timestamps/`final_at`, and the mandated tests — then review it, merge it and record the session.
- **Outcome:** Merged PR #37 (DLR ingestion, merge `a86e836`) and PR #38 (terminal status counts in `run_1k.py`, merge `925972b`). 142 tests pass, `ruff` and `mypy app` clean, CI green, migration chain verified from an empty database. Council: three seats, 9/10 each, no blocking findings.
- **Issues/commits:** issue #11; PR #37; PR #38; merge commits `a86e836d9405aae7eb50c9c5c5c7bc313e41a168` and `925972bb3568b64dfc08bece428944438192e6fd`; branch `feat/dlr-11` commits `8184651` → `8884795`; branch `feat/load-dlr-statuses` commit `8b47892`
- **Complete export:** `14-dlr-ingestion-11.json` (inside transcripts.zip)

## Transcript

### User — implement #11 in the worktree

> Implement GitHub issue #11 in this worktree: DLR ingestion. This is the critical-path ticket; do the minimum that satisfies its MVP path, nothing from #13/#15/#20/#21/#22.

Read `AGENTS.md`, issue #11 and the existing message/dispatch/carrier code. Established the scope from the ticket's MVP "Keep" blockquote, not the full acceptance criteria.

Built:

- `gateway/app/api/dlr/` — `POST /carrier/dlr` (app-level, outside `/v1`).
- `gateway/app/core/dlr.py` — carrier status map, forward-only terminal update, inbox insert, pending-receipt lock, sweep query.
- `gateway/app/db/models.py` — `DlrState`, `DlrInbox`, `messages.final_at`, event `source`/`occurred_at`/`received_at`.
- `gateway/migrations/versions/c3a8f1d4e6b2_add_dlr_ingestion.py` — revises `a56d3be64546`.
- `gateway/app/worker/dispatch.py` — reconcile parked receipts inside `record_submitted`; 5-second sweep in `run()`.
- `gateway/tests/test_dlr.py` — seven mandated scenarios; `sign_dlr()` helper.
- `gateway/README.md` — endpoint entry.

Key decisions:

- Read the raw body and verify hex HMAC-SHA256 with `hmac.compare_digest` **before** any DB work; missing/wrong signature is `401` with zero writes.
- Map `DELIVRD/UNDELIV/EXPIRED` to terminal statuses; unknown status/body is `400`.
- `dlr_inbox` is unique on `(carrier, carrier_id, status, occurred_at)`; duplicate receipts are `DUPLICATE`.
- Unknown carrier id → `PENDING` and 200; later reconciled.
- Terminal application is one conditional `UPDATE ... WHERE status IN (ACCEPTED, QUEUED, SUBMITTED)`; first terminal wins, `FAILED` is absorbing, zero rows means the receipt is `REJECTED` with `MESSAGE_ALREADY_TERMINAL`.
- `final_at` uses `COALESCE(final_at, now())`; terminal events carry `source='dlr'`, carrier `occurred_at`, gateway `received_at`.
- Early reconciliation happens in the same transaction that saves `carrier_id`: insert `SUBMITTED` (source `dlr`) first, then apply the terminal receipt.
- A sweep joins `PENDING` receipts to messages on `(carrier, carrier_id)` to close the insert-after-query race.
- Deferred `X-Carrier` (#23) and a rejection-reason taxonomy.

Committed as `8184651`, `0ea4161`, `08aba51`, `433df93`; opened PR #37. Baseline 133 tests → 140.

### Review comment — naming and the event unique pair

> prefer to name this... NONTERMINAL_STATUS?

Renamed `TERMINAL_PREDECESSORS` → `NONTERMINAL_STATUS` (`5743134`).

> this is set in our constraints right? unique message_id + status pair

Confirmed: `MessageEvent.__table_args__` has `UniqueConstraint("message_id", "status")`, created by migration `0d3c682e1245` as `uq_message_events_message_id_status`; the event `ON CONFLICT` uses it.

### User — teach the change layer by layer

> `$teach` Can you illustrate to me your changes? Layer by layer, and how it is integrated from our worker dispatch logic.

Created a teaching workspace outside the repo at `~/teach/dcc-sms-gateway-dlr-11` so lesson files never pollute the PR:

- `MISSION.md`, `RESOURCES.md`, `NOTES.md`.
- `lessons/0001-dlr-ingestion-layer-by-layer.html` — seven layers, state diagram, early-DLR sequence, race table, retrieval quiz.
- `reference/dlr-ingestion-map.html` — one-page cheat sheet.
- `assets/course.css` + `assets/build.py` — shared stylesheet inlined by the build for self-contained lessons.

The seven layers: signature gate → payload/status map → inbox → forward-only gate → event/timestamps → worker reconciliation → sweep.

### Review comments — split handler/models, simplify the gate

> place in dlr/handler.py
> place in dlr/models.py
> smart and all but i think doing a simple payload.status not in CARRIER_STATUS_MAP would be easier to read.
> are these needed? same with the rest of the functions and files. remove if unnecessary
> is this the case where the "webhook" is the first one to reply?

Applied (`a17a818`):

- `DlrPayload` moved to `api/dlr/models.py`; `signature_matches` moved to `api/dlr/handler.py`.
- Status check became a membership test before lookup.
- Removed keyword-only `*` markers; dropped `settle_dlrs`, its `state` argument and unused count; replaced it with `reconcile_dlr`; removed the unused sweep `limit` parameter in favour of `SWEEP_LIMIT`.
- Confirmed the L152 comment: yes, the carrier's inbound DLR can beat the worker's submit 200. The comment now says that explicitly.

### Review comment — is the DLR inbox necessary?

> Is this DLR Inbox absolutely necessary? I mean I get that its a log of every DLR we receive, but whats more important is the Message status that we obtain from each DLR?

The message remains the source of truth. The inbox is load-bearing for three things the message row cannot do:

1. Durable parking when the message has no `carrier_id` yet (no row to attach the receipt to).
2. A receipt identity for idempotency before a message exists.
3. Rejection evidence required by #11 when a DLR targets an already-terminal message.

Trimmed the docstring line marked "omit" and clarified the model docstring (`2e12627`).

### User — parked receipts and worker response logging

> So primarily, we use the DLR Inbox to store the parked receipts? ... What does the worker log on response from the carrier endpoint

Clarified the carrier's own `p_early_dlr` path (`carrier/app/submit/controller.py`): 5% of submits book the DLR before returning the 200; otherwise the DLR is scheduled 0.5–10 s later. The worker waits for the submit response, not the DLR; the API parks the receipt because the worker has not committed `carrier_id` yet.

On a successful 200 the worker logs **nothing**; it records `SUBMITTED` in the database. Logging exists only for failures: limiter down, HTTP error/timeout, non-200, dispatch crash, sweep failure, round failure.

### User — duplication guard and PENDING state

> What line of code guards duplication of DLR?

`core/dlr.py` `on_conflict_do_nothing` on the inbox insert, backed by the unique receipt key; the event `(message_id, status)` unique pair is the second guard.

> do we store parked receipts as state "PENDING"?

Yes. `PENDING` is the column default; an unknown carrier id leaves it committed as `PENDING`. A known message flips it to `PROCESSED`/`REJECTED` in the same transaction. Reconciliation moves `PENDING` → `RECONCILED`/`REJECTED`.

> ah so the Gateway API is the one returns "PARKED" to the Carrier? A bit confusing, should we just use the PENDING nomenclature everywhere

Changed `ingest_dlr` to return the inbox vocabulary (`PROCESSED`, `PENDING`, `DUPLICATE`, `REJECTED`) instead of `APPLIED`/`PARKED` (`39f042b`); updated tests, README and the lesson.

### Review comment — lock_pending_dlrs

> why do we call it lock_pending_dlrs? do we ensure that whatever we are working on next is actually a pending message

Renamed to `lock_pending_receipts` and the local set to `pending_receipts`; the docstring now says these are `dlr_inbox` rows, not messages. The message guard is `apply_terminal_dlr`'s non-terminal predicate. `SKIP LOCKED` means the caller only receives rows it actually acquired (`f80bb19`).

### User — explain the dispatch changes

> I got a bit lost. sorry can you explain the context surrounding this dispatch.py changes?

Walked through the original claim → submit → `record_submitted` pipeline, then why the early-DLR case makes `record_submitted` the reconciliation seam. Explained the one transaction (save carrier id, lock pending receipts, insert `SUBMITTED`, apply terminals, mark `RECONCILED`), the sweep, and the two separate guards: pending receipts vs non-terminal message.

### User — verify the record_submitted mental model

> Let me get this straight... Is my understanding correct

Corrected three details: the receipts are scoped to the specific `(carrier, carrier_id)`, not the whole carrier; the message is already `message_id` (no lookup inside the loop); and the message only moves beyond `SUBMITTED` when a parked receipt exists. The common path is: `record_submitted` ends at `SUBMITTED`; the API applies a later DLR directly.

### User — council review

> Fine by me, run a `$council` to deliberate whether these are the minimal changes required before we merge.

Pre-council checks: PR #37 mergeable and CI green, 140 tests, `ruff`/`mypy` clean, and the full Alembic chain applied to a fresh `sms_fresh_check` database with the expected columns/constraints.

Council seats and scores:

| Seat | Model | Round 1 |
| --- | --- | --- |
| DeepSeek | `opencode-go/deepseek-v4.1-flash` | 9/10 |
| GLM | `opencode-go/glm-5.3-flash` | 9/10 |
| Muse | `opencode-go/muse-spark-1.3-contributor` | 9/10 |

Unanimous: no blocking findings; these are the minimal changes required before merge. Their independent probes covered conflicting terminals, simultaneous duplicates, early-DLR races, DLRs against `FAILED`, and non-ASCII signatures.

Non-blocking findings recorded in the PR description:

- Only `DELIVRD` was applied in tests; `UNDELIV`/`EXPIRED` mapping was untested.
- The synthetic `SUBMITTED` event has `source="dlr"` but null `occurred_at`/`received_at`.
- `final_at`'s comment mentions `FAILED`, but #13 sets that.
- The 5-second sweep cadence in `run()` is untested.
- Receipts that never resolve stay `PENDING` forever; future retention.
- Mixed return vocabulary and the read API not yet exposing the new event fields (#18).

### User — add the cheap parametrization

> wdym by cheap parametrization? as in using the enum instead of raw string?

Clarified it meant `pytest.mark.parametrize` over the three wire codes, not changing the enum/map. Added a parametrized test covering `DELIVRD`, `UNDELIV`, and `EXPIRED` with status, event source/timestamps, `final_at` and `PROCESSED` inbox state (`8884795`). 142 tests. PR body updated with the post-review note.

### User — can run_1k track paths without webhooks?

> since we still don't have the webhooks, we cant update run_1k script yet to track the different paths right?

Corrected the premise: `run_1k.py` polls Postgres directly, so webhooks (#16) are irrelevant. The real issue was `SETTLED` including `SUBMITTED`, which stopped the drain before DLRs. The full #20 load script remains blocked by #13/#15/#16.

### User — track statuses in run_1k

> sure, let's track the statuses in run_1k

Created stacked branch `feat/load-dlr-statuses`, changed `SETTLED` → `TERMINAL = {DELIVERED, UNDELIVERED, EXPIRED, FAILED}`, and added `delivered`/`undelivered`/`expired`/`failed`/`stuck` output. Opened PR #38 based on `feat/dlr-11` (`8b47892`).

### User — merge and transcript

> now let's merge please. then write this session in the transcript

Merged PR #37 with a merge commit (`a86e836`), retargeted #38 to `main`, then merged #38 (`925972b`). Fast-forwarded local `main` and exported this session as `14-dlr-ingestion-11.json`.

## Artifacts

- `gateway/app/api/dlr/controller.py` — `POST /carrier/dlr`, raw-body read, parse/validation, result mapping.
- `gateway/app/api/dlr/handler.py` — `signature_matches` raw-body HMAC.
- `gateway/app/api/dlr/models.py` — `DlrPayload`.
- `gateway/app/core/dlr.py` — `CARRIER_STATUS_MAP`, `NONTERMINAL_STATUS`, `apply_terminal_dlr`, `lock_pending_receipts`, `reconcile_dlr`, `ingest_dlr`, `sweep_parked_dlrs`.
- `gateway/app/worker/dispatch.py` — `record_submitted` reconciliation, `reconcile_parked_dlrs`, 5-second sweep in `run()`.
- `gateway/app/db/models.py` — `DlrState`, `DlrInbox`, `Message.final_at`, `MessageEvent.source/occurred_at/received_at`.
- `gateway/migrations/versions/c3a8f1d4e6b2_add_dlr_ingestion.py` — schema.
- `gateway/tests/test_dlr.py`, `tests/helpers.py::sign_dlr` — coverage.
- `gateway/tests/test_schema.py` — new index assertion.
- `gateway/README.md` — endpoint entry.
- `scripts/run_1k.py` — terminal-state wait and outcome counts (PR #38).
- Teaching workspace `~/teach/dcc-sms-gateway-dlr-11/` — mission, resources, lesson 0001, reference map, shared CSS/build.

## Verification

- `cd gateway && uv run pytest -q` — 142 passed.
- `uv run ruff check .` and `uv run mypy app` — clean.
- CI `Lint, typecheck and test` — green on both PR heads.
- Alembic `upgrade head` on an empty database — the full chain applies; `dlr_inbox` columns/constraints, `messages.final_at`, and event `source/occurred_at/received_at` present.
- Council — 9/10 × 3, no blocking findings.
- PR #37 merged as `a86e836`; PR #38 merged as `925972b`.

## Deferred / open

- `X-Carrier` multi-carrier support (#23) and a detailed rejection-reason taxonomy.
- Set `final_at` on `FAILED` when #13 lands.
- Test the worker's 5-second sweep cadence.
- Receipts that never resolve stay `PENDING`; consider retention in #13/#22.
- Expose `final_at`/event `source`/`occurred_at` in the read API (#18).
- Full 10k/OTP/billing load script (#20) remains blocked by #13/#15/#16.
- `run_1k.py` has not yet been run against a live stack after the terminal-state change; the next full run should record the delivered/undelivered/expired counts.
- Secrets review: the export contains only local test/demo values (`test-dlr-secret`, `test-admin-key`, `dcc_acme_demo_key`, `sms:sms`), no tokens or private keys; re-check before zipping at submission.
