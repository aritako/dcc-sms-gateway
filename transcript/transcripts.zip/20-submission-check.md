# Session 20 — Submission readiness, DESIGN polish and transcript archive

- **Date:** 2026-11-22
- **Agent/model:** `opencode-go/deepseek-v4.1-flash` (high)
- **Goal:** Check the repo against the assignment brief, tighten the remaining DESIGN answers, review the #11/#13/#15/#20/#21/#22 work, and build the final submission transcript archive.
- **Outcome:** The backend prototype is submission-ready apart from pushing the transcript zip. `main` is clean at `25b6d33` with green CI. Verified 176 gateway tests and 12 carrier tests pass, ruff and mypy are clean, `make smoke` passes all four checks, and the Compose stack is healthy. Completed the Core Design section, rewrote the fairness answer, unslopped both, and added the Q2 proof paragraph with the concrete table constraints. Built `transcript/transcripts.zip` from sessions 01–20 and committed it.
- **Issues/commits:** [#22](https://github.com/aritako/dcc-sms-gateway/issues/22); `25b6d33` (docs cleanup), transcript commit follows this session.
- **Complete export:** `20-submission-check.json` (inside `transcripts.zip`). The OpenCode password that appeared in a local environment dump was redacted before zipping.

## Transcript

### User

Asked for a read-only onboarding brief on the next backend tickets: current state, #11 DLR ingestion, one paragraph each for #13/#15/#20/#21/#22, recommended order, and what is being skipped. Supplied the brief PDF and a list of the open prototype tickets.

### Assistant

Read `AGENTS.md`, every open issue, and the gateway, carrier and script code. Verified 133 gateway and 12 carrier tests at the time. Produced the briefing, then corrected it after reading the assignment PDF: the seven mandated tests are explicit, webhooks (#16) and the dashboard (#17/#18) are core requirements rather than bonus work, and the grading weights put 45% on #11 plus #13.

Explained the carrier dedupe path, the `accept` store and the two-check race. Clarified the claim lease, `FOR UPDATE SKIP LOCKED`, `next_attempt_at` backoff and the late-200-after-FAILED guard.

### User

Asked whether the DESIGN answer to question 1 was correct, then whether the late-acceptance case is reachable. Asked what a ledger is, why money is exactly once, and how SSE works.

### Assistant

Corrected the crash answer: the sweep cannot match a DLR before `carrier_id` is saved, so the recovery path is lease expiry, resubmit with the same `message_id`, carrier dedupe, then `record_submitted` reconciling the parked receipt. Explained that with a 2 second timeout and a 30 second lease the late-200 branch is a defensive guard for a worker that outlives its lease, not a normal path.

### User

Asked for the fairness answer, then for it and Core Design to be unslopped.

### Assistant

Wrote the fairness answer around the equal-share claim query in `scheduler.py`: `K // N` plus one for the first `K % N`, FIFO by `due_at` and `id`, backfill from the global due list, and the honest 50-tenant limitation. Unsloped it by removing en dashes, parentheses, jargon and metaphor, splitting sentences and naming the worker as the actor.

### User

Asked for the final submission check.

### Assistant

Verified the committed state:

```text
main 25b6d33, clean, CI success
pytest       176 passed (gateway), 12 passed (carrier)
ruff         clean
mypy         40 files, clean
make smoke   4/4 PASS, terminal in 8.1s
compose      api, carrier, 3 workers, postgres, redis healthy
```

Recorded the two open items: `DESIGN.md` is 2,305 words against a 1–2 page brief, and #22 is still open. Exported this session, redacted the environment password, wrote this summary, and built the cumulative archive.

### Notes

- The first local test run deadlocked in Postgres because two `pytest` processes overlapped on `sms_test` after a server restart. A clean rerun passed 176.
- Raw JSON and Markdown exports stay ignored; only `transcript/transcripts.zip` is committed.
